import { RequestHandler } from "express";
import { mockProjects, mockSectors, formatHeatScore } from "../../client/data/mockData.js";

// /api/trending - 获取热门项目
export const getTrendingProjects: RequestHandler = (req, res) => {
  try {
    const { 
      time_period = '24h', 
      limit = 10, 
      sector,
      sort_by = 'heat_score' 
    } = req.query;

    let filteredProjects = [...mockProjects];

    // 按板块过滤
    if (sector && typeof sector === 'string') {
      filteredProjects = filteredProjects.filter(project => 
        project.categories.some(cat => 
          cat.toLowerCase() === sector.toLowerCase()
        )
      );
    }

    // 按热度排序
    filteredProjects.sort((a, b) => {
      if (sort_by === 'heat_score') {
        return b.heatScore - a.heatScore;
      }
      if (sort_by === 'name') {
        return a.name.localeCompare(b.name);
      }
      return 0;
    });

    // 限制返回数量
    const limitNum = parseInt(limit as string) || 10;
    const projects = filteredProjects.slice(0, limitNum);

    const response = {
      success: true,
      data: {
        projects: projects.map(project => ({
          id: project.id,
          name: project.name,
          description: project.intro,
          logo_url: project.logo,
          heat_score: project.heatScore,
          categories: project.categories,
          chains: project.chains,
          social_links: {
            website: project.websiteUrl,
            twitter: project.twitterUrl,
            telegram: project.telegramUrl,
            discord: project.discordUrl
          },
          market_data: {
            market_cap: project.marketCap,
            volume_24h: project.volume24h,
            price_change_24h: project.priceChange24h
          },
          status: project.status,
          created_at: project.createdAt
        })),
        total_count: filteredProjects.length,
        time_period,
        last_updated: new Date().toISOString()
      }
    };

    res.json(response);
  } catch (error) {
    console.error('Error fetching trending projects:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
};

// /api/sectors - 获取板块热度
export const getSectorHeatmap: RequestHandler = (req, res) => {
  try {
    const { time_period = '24h' } = req.query;

    const sectorsWithProjects = mockSectors.map(sector => {
      const sectorProjects = mockProjects.filter(project =>
        project.categories.some(cat => cat === sector.name)
      );

      return {
        id: sector.id,
        name: sector.name,
        heat_score: sector.heatScore,
        project_count: sector.projectCount,
        description: sector.description,
        change_24h: sector.change24h,
        color: sector.color,
        top_projects: sectorProjects
          .sort((a, b) => b.heatScore - a.heatScore)
          .slice(0, 3)
          .map(p => ({
            name: p.name,
            heat_score: p.heatScore,
            logo_url: p.logo
          }))
      };
    });

    const response = {
      success: true,
      data: {
        sectors: sectorsWithProjects,
        time_period,
        last_updated: new Date().toISOString()
      }
    };

    res.json(response);
  } catch (error) {
    console.error('Error fetching sector heatmap:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
};

// /api/statistics - 获取实时统计
export const getLiveStatistics: RequestHandler = (req, res) => {
  try {
    const totalProjects = mockProjects.length;
    const activeSectors = mockSectors.length;
    const trendingToday = mockProjects.filter(p => p.status === 'trending').length;
    const totalUsers = 2847; // 模拟用户数

    const topSector = mockSectors
      .sort((a, b) => b.heatScore - a.heatScore)[0];

    const avgHeatScore = mockProjects
      .reduce((sum, p) => sum + p.heatScore, 0) / totalProjects;

    const response = {
      success: true,
      data: {
        total_projects: totalProjects,
        active_sectors: activeSectors,
        today_trending: trendingToday,
        total_users: totalUsers,
        avg_heat_score: Math.round(avgHeatScore),
        most_active_sector: topSector.name,
        total_heat_score: mockProjects.reduce((sum, p) => sum + p.heatScore, 0),
        last_updated: new Date().toISOString()
      }
    };

    res.json(response);
  } catch (error) {
    console.error('Error fetching statistics:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
};

// /api/search - 搜索项目
export const searchProjects: RequestHandler = (req, res) => {
  try {
    const { 
      q: query = '',
      sectors,
      chains,
      limit = 20,
      offset = 0
    } = req.query;

    let results = [...mockProjects];

    // 文本搜索
    if (query && typeof query === 'string') {
      const searchTerm = query.toLowerCase();
      results = results.filter(project =>
        project.name.toLowerCase().includes(searchTerm) ||
        project.intro.toLowerCase().includes(searchTerm) ||
        project.description.toLowerCase().includes(searchTerm) ||
        project.categories.some(cat => cat.toLowerCase().includes(searchTerm))
      );
    }

    // 板块过滤
    if (sectors && typeof sectors === 'string') {
      const sectorList = sectors.split(',');
      results = results.filter(project =>
        project.categories.some(cat => sectorList.includes(cat))
      );
    }

    // 链过滤
    if (chains && typeof chains === 'string') {
      const chainList = chains.split(',');
      results = results.filter(project =>
        project.chains.some(chain => chainList.includes(chain))
      );
    }

    // 分页
    const limitNum = parseInt(limit as string) || 20;
    const offsetNum = parseInt(offset as string) || 0;
    const paginatedResults = results.slice(offsetNum, offsetNum + limitNum);

    // 统计facets
    const sectorCounts = new Map<string, number>();
    const chainCounts = new Map<string, number>();

    results.forEach(project => {
      project.categories.forEach(cat => {
        sectorCounts.set(cat, (sectorCounts.get(cat) || 0) + 1);
      });
      project.chains.forEach(chain => {
        chainCounts.set(chain, (chainCounts.get(chain) || 0) + 1);
      });
    });

    const response = {
      success: true,
      data: {
        projects: paginatedResults.map(project => ({
          id: project.id,
          name: project.name,
          description: project.intro,
          logo_url: project.logo,
          heat_score: project.heatScore,
          categories: project.categories,
          chains: project.chains,
          status: project.status
        })),
        total_count: results.length,
        facets: {
          sectors: Array.from(sectorCounts.entries()).map(([name, count]) => ({
            name,
            count
          })),
          chains: Array.from(chainCounts.entries()).map(([name, count]) => ({
            name,
            count
          }))
        },
        pagination: {
          limit: limitNum,
          offset: offsetNum,
          has_more: offsetNum + limitNum < results.length
        }
      }
    };

    res.json(response);
  } catch (error) {
    console.error('Error searching projects:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
};

// /api/project/:id - 获取项目详情
export const getProjectDetail: RequestHandler = (req, res) => {
  try {
    const { id } = req.params;
    const project = mockProjects.find(p => p.id === id);

    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }

    // 模拟评论数据
    const mockComments = [
      {
        id: '1',
        user_name: 'CryptoAnalyst',
        comment: 'Great project with strong fundamentals and active community.',
        rating: 5,
        created_at: '2024-01-15T10:30:00Z'
      },
      {
        id: '2',
        user_name: 'Web3Explorer',
        comment: 'Interesting use case, but still early stage development.',
        rating: 4,
        created_at: '2024-01-14T15:45:00Z'
      }
    ];

    const response = {
      success: true,
      data: {
        project: {
          id: project.id,
          name: project.name,
          description: project.description,
          logo_url: project.logo,
          heat_score: project.heatScore,
          categories: project.categories,
          chains: project.chains,
          social_links: {
            website: project.websiteUrl,
            twitter: project.twitterUrl,
            telegram: project.telegramUrl,
            discord: project.discordUrl
          },
          market_data: {
            market_cap: project.marketCap,
            volume_24h: project.volume24h,
            price_change_24h: project.priceChange24h
          },
          followers: project.followers,
          tags: project.tags,
          status: project.status,
          created_at: project.createdAt
        },
        comments: mockComments,
        average_rating: 4.5,
        total_comments: mockComments.length,
        gpt_analysis: {
          summary: `${project.name} is a ${project.categories[0]} project that shows strong potential in the Web3 space.`,
          strengths: ['Active community', 'Strong technology', 'Good tokenomics'],
          risks: ['Market volatility', 'Regulatory uncertainty'],
          market_potential: 'high' as const,
          confidence_score: 0.85
        }
      }
    };

    res.json(response);
  } catch (error) {
    console.error('Error fetching project detail:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
};
