export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      projects: {
        Row: {
          id: string
          name: string
          logo: string
          intro: string
          description: string
          categories: string[]
          chains: string[]
          twitter_url: string | null
          telegram_url: string | null
          discord_url: string | null
          website_url: string | null
          heat_score: number
          source_platform: string
          created_at: string
          updated_at: string
          market_cap: string | null
          volume_24h: string | null
          price_change_24h: number | null
          followers: Json | null
          tags: string[] | null
          status: 'active' | 'new' | 'trending' | 'rising'
        }
        Insert: {
          id?: string
          name: string
          logo: string
          intro: string
          description: string
          categories: string[]
          chains: string[]
          twitter_url?: string | null
          telegram_url?: string | null
          discord_url?: string | null
          website_url?: string | null
          heat_score: number
          source_platform: string
          created_at?: string
          updated_at?: string
          market_cap?: string | null
          volume_24h?: string | null
          price_change_24h?: number | null
          followers?: Json | null
          tags?: string[] | null
          status?: 'active' | 'new' | 'trending' | 'rising'
        }
        Update: {
          id?: string
          name?: string
          logo?: string
          intro?: string
          description?: string
          categories?: string[]
          chains?: string[]
          twitter_url?: string | null
          telegram_url?: string | null
          discord_url?: string | null
          website_url?: string | null
          heat_score?: number
          source_platform?: string
          created_at?: string
          updated_at?: string
          market_cap?: string | null
          volume_24h?: string | null
          price_change_24h?: number | null
          followers?: Json | null
          tags?: string[] | null
          status?: 'active' | 'new' | 'trending' | 'rising'
        }
      }
      sectors: {
        Row: {
          id: string
          name: string
          heat_score: number
          project_count: number
          color: string
          change_24h: number
          description: string
          top_projects: string[]
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          heat_score: number
          project_count: number
          color: string
          change_24h: number
          description: string
          top_projects: string[]
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          heat_score?: number
          project_count?: number
          color?: string
          change_24h?: number
          description?: string
          top_projects?: string[]
          created_at?: string
          updated_at?: string
        }
      }
      heat_history: {
        Row: {
          id: string
          project_id: string
          heat_score: number
          recorded_at: string
          metadata: Json | null
        }
        Insert: {
          id?: string
          project_id: string
          heat_score: number
          recorded_at?: string
          metadata?: Json | null
        }
        Update: {
          id?: string
          project_id?: string
          heat_score?: number
          recorded_at?: string
          metadata?: Json | null
        }
      }
      twitter_metrics: {
        Row: {
          id: string
          project_id: string
          followers_count: number
          mentions_24h: number
          engagement_rate: number
          recorded_at: string
        }
        Insert: {
          id?: string
          project_id: string
          followers_count: number
          mentions_24h: number
          engagement_rate: number
          recorded_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          followers_count?: number
          mentions_24h?: number
          engagement_rate?: number
          recorded_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      project_status: 'active' | 'new' | 'trending' | 'rising'
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

// Helper types for transforming between Supabase and frontend
export interface SupabaseProject extends Database['public']['Tables']['projects']['Row'] {}

export interface SupabaseSector extends Database['public']['Tables']['sectors']['Row'] {}

// Transform Supabase data to frontend Project type
export function transformSupabaseProject(supabaseProject: SupabaseProject): import('@/data/mockData').Project {
  return {
    id: supabaseProject.id,
    name: supabaseProject.name,
    logo: supabaseProject.logo,
    intro: supabaseProject.intro,
    description: supabaseProject.description,
    categories: supabaseProject.categories,
    chains: supabaseProject.chains,
    twitterUrl: supabaseProject.twitter_url,
    telegramUrl: supabaseProject.telegram_url,
    discordUrl: supabaseProject.discord_url,
    websiteUrl: supabaseProject.website_url,
    heatScore: supabaseProject.heat_score,
    sourcePlatform: supabaseProject.source_platform,
    createdAt: supabaseProject.created_at,
    marketCap: supabaseProject.market_cap,
    volume24h: supabaseProject.volume_24h,
    priceChange24h: supabaseProject.price_change_24h,
    followers: supabaseProject.followers as any,
    tags: supabaseProject.tags,
    status: supabaseProject.status,
  };
}

// Transform Supabase data to frontend Sector type
export function transformSupabaseSector(supabaseSector: SupabaseSector): import('@/data/mockData').Sector {
  return {
    id: supabaseSector.id,
    name: supabaseSector.name,
    heatScore: supabaseSector.heat_score,
    projectCount: supabaseSector.project_count,
    color: supabaseSector.color,
    change24h: supabaseSector.change_24h,
    description: supabaseSector.description,
    topProjects: supabaseSector.top_projects,
  };
}

// Transform frontend data to Supabase format
export function transformToSupabaseProject(project: import('@/data/mockData').Project): Database['public']['Tables']['projects']['Insert'] {
  return {
    id: project.id,
    name: project.name,
    logo: project.logo,
    intro: project.intro,
    description: project.description,
    categories: project.categories,
    chains: project.chains,
    twitter_url: project.twitterUrl,
    telegram_url: project.telegramUrl,
    discord_url: project.discordUrl,
    website_url: project.websiteUrl,
    heat_score: project.heatScore,
    source_platform: project.sourcePlatform,
    created_at: project.createdAt,
    market_cap: project.marketCap,
    volume_24h: project.volume24h,
    price_change_24h: project.priceChange24h,
    followers: project.followers as Json,
    tags: project.tags,
    status: project.status,
    updated_at: new Date().toISOString(),
  };
}
