export interface Project {
  id: string;
  name: string;
  logo: string;
  intro: string;
  description: string;
  categories: string[];
  chains: string[];
  twitterUrl?: string;
  telegramUrl?: string;
  discordUrl?: string;
  websiteUrl?: string;
  heatScore: number;
  sourcePlatform: string;
  createdAt: string;
  marketCap?: string;
  volume24h?: string;
  priceChange24h?: number;
  followers?: {
    twitter?: number;
    telegram?: number;
    discord?: number;
  };
  tags?: string[];
  status: 'active' | 'new' | 'trending' | 'rising';
}

export interface Sector {
  id: string;
  name: string;
  heatScore: number;
  projectCount: number;
  color: string;
  change24h: number;
  description: string;
  topProjects: string[];
}

export const mockProjects: Project[] = [
  {
    id: "1",
    name: "Friend.Tech",
    logo: "https://pbs.twimg.com/profile_images/1691531027405959168/9aJ7GvCj_400x400.jpg",
    intro: "Decentralized social trading platform",
    description: "Friend.tech is a decentralized social media protocol built on Base where users can buy and sell shares in each other's social media profiles, creating a new paradigm for social networking and monetization.",
    categories: ["SocialFi", "DeFi"],
    chains: ["Base"],
    twitterUrl: "https://twitter.com/friendtech",
    telegramUrl: "https://t.me/friendtech",
    websiteUrl: "https://friend.tech",
    heatScore: 20400,
    sourcePlatform: "Twitter",
    createdAt: "2024-01-15",
    marketCap: "$150M",
    volume24h: "$12.5M",
    priceChange24h: 15.4,
    followers: { twitter: 250000, telegram: 45000 },
    tags: ["Hot", "Social", "Trading"],
    status: 'trending',
  },
  {
    id: "2",
    name: "Jupiter",
    logo: "https://pbs.twimg.com/profile_images/1745832773797662720/NFfKq7mC_400x400.jpg",
    intro: "Solana's key liquidity aggregator",
    description: "Jupiter is the key liquidity aggregator for Solana, offering the widest range of tokens and best route discovery between any token pair.",
    categories: ["DeFi", "DEX"],
    chains: ["Solana"],
    twitterUrl: "https://twitter.com/JupiterExchange",
    telegramUrl: "https://t.me/jup_dev",
    websiteUrl: "https://jup.ag",
    heatScore: 18100,
    sourcePlatform: "Telegram",
    createdAt: "2024-01-10",
    marketCap: "$890M",
    volume24h: "$145M",
    priceChange24h: 8.2,
    followers: { twitter: 180000, telegram: 62000 },
    tags: ["DEX", "Aggregator", "Solana"],
    status: 'active',
  },
  {
    id: "3",
    name: "Farcaster",
    logo: "https://pbs.twimg.com/profile_images/1681695471354834944/I8gDJCvs_400x400.jpg",
    intro: "Decentralized social network protocol",
    description: "Farcaster is a protocol for building decentralized social apps. Users own their accounts and relationships with other users, and developers have the freedom to build with open APIs.",
    categories: ["SocialFi", "Infrastructure"],
    chains: ["Ethereum", "Optimism"],
    twitterUrl: "https://twitter.com/farcaster_xyz",
    telegramUrl: "https://t.me/farcasterxyz",
    websiteUrl: "https://farcaster.xyz",
    heatScore: 15700,
    sourcePlatform: "Discord",
    createdAt: "2024-01-20",
    marketCap: "$320M",
    volume24h: "$8.9M",
    priceChange24h: 12.7,
    followers: { twitter: 95000, discord: 35000 },
    tags: ["Protocol", "Social", "Decentralized"],
    status: 'rising',
  },
  {
    id: "4",
    name: "Kamino",
    logo: "https://pbs.twimg.com/profile_images/1720848892396343296/QvZ5DTAV_400x400.jpg",
    intro: "Automated liquidity solutions for Solana",
    description: "Kamino Finance provides automated liquidity solutions for concentrated liquidity market makers on Solana, optimizing yields through sophisticated strategies.",
    categories: ["DeFi", "Yield Farming"],
    chains: ["Solana"],
    twitterUrl: "https://twitter.com/kamino_finance",
    telegramUrl: "https://t.me/kamino_finance",
    websiteUrl: "https://kamino.finance",
    heatScore: 12300,
    sourcePlatform: "Twitter",
    createdAt: "2024-01-25",
    marketCap: "$180M",
    volume24h: "$23M",
    priceChange24h: -3.2,
    followers: { twitter: 78000, telegram: 25000 },
    tags: ["Yield", "Automated", "Liquidity"],
    status: 'active',
  },
  {
    id: "5",
    name: "Pyth Network",
    logo: "https://pbs.twimg.com/profile_images/1639295203075584001/nVhwhYKJ_400x400.jpg",
    intro: "High-fidelity financial market data oracle",
    description: "Pyth Network is a first-party oracle that publishes financial market data to multiple blockchains. The network comprises some of the world's largest exchanges and market makers.",
    categories: ["Oracle", "Infrastructure"],
    chains: ["Solana", "Ethereum", "BNB"],
    twitterUrl: "https://twitter.com/PythNetwork",
    telegramUrl: "https://t.me/Pyth_Network",
    websiteUrl: "https://pyth.network",
    heatScore: 11800,
    sourcePlatform: "Twitter",
    createdAt: "2024-02-01",
    marketCap: "$1.2B",
    volume24h: "$67M",
    priceChange24h: 5.8,
    followers: { twitter: 125000, telegram: 48000 },
    tags: ["Oracle", "Data", "Multi-chain"],
    status: 'active',
  },
  {
    id: "6",
    name: "Celestia",
    logo: "https://pbs.twimg.com/profile_images/1698003201403957248/d5TKP7vt_400x400.jpg",
    intro: "Modular blockchain for data availability",
    description: "Celestia is a modular consensus and data network, built to enable anyone to easily deploy their own blockchain with minimal overhead.",
    categories: ["Layer1", "Infrastructure"],
    chains: ["Celestia"],
    twitterUrl: "https://twitter.com/CelestiaOrg",
    telegramUrl: "https://t.me/celestiacommunity",
    websiteUrl: "https://celestia.org",
    heatScore: 9800,
    sourcePlatform: "Twitter",
    createdAt: "2024-02-05",
    marketCap: "$2.1B",
    volume24h: "$89M",
    priceChange24h: 18.9,
    followers: { twitter: 290000, telegram: 85000 },
    tags: ["Modular", "DA", "Layer1"],
    status: 'new',
  },
  {
    id: "7",
    name: "Render Network",
    logo: "https://pbs.twimg.com/profile_images/1743334629433933824/2aUj8cLx_400x400.jpg",
    intro: "Decentralized GPU rendering network",
    description: "Render Network is a leading provider of decentralized GPU based rendering solutions, revolutionizing the digital creation process.",
    categories: ["AI", "Infrastructure", "Computing"],
    chains: ["Ethereum", "Polygon"],
    twitterUrl: "https://twitter.com/rendernetwork",
    telegramUrl: "https://t.me/rendernetwork",
    websiteUrl: "https://rendernetwork.com",
    heatScore: 14200,
    sourcePlatform: "Twitter",
    createdAt: "2024-01-30",
    marketCap: "$2.8B",
    volume24h: "$45M",
    priceChange24h: 22.1,
    followers: { twitter: 180000, telegram: 32000 },
    tags: ["GPU", "Rendering", "AI"],
    status: 'trending',
  },
  {
    id: "8",
    name: "Jito",
    logo: "https://pbs.twimg.com/profile_images/1627034738345992198/KdpBJhLz_400x400.jpg",
    intro: "MEV infrastructure for Solana",
    description: "Jito provides MEV infrastructure for Solana, enabling validators and searchers to capture maximum extractable value while maintaining network security.",
    categories: ["Infrastructure", "MEV"],
    chains: ["Solana"],
    twitterUrl: "https://twitter.com/jito_sol",
    telegramUrl: "https://t.me/jito_sol",
    websiteUrl: "https://jito.wtf",
    heatScore: 13500,
    sourcePlatform: "Twitter",
    createdAt: "2024-02-10",
    marketCap: "$450M",
    volume24h: "$28M",
    priceChange24h: 7.3,
    followers: { twitter: 95000, telegram: 18000 },
    tags: ["MEV", "Validator", "Infrastructure"],
    status: 'rising',
  },
  {
    id: "9",
    name: "Blur",
    logo: "https://pbs.twimg.com/profile_images/1593304942210674689/WTlG_vPJ_400x400.jpg",
    intro: "NFT marketplace for pro traders",
    description: "Blur is the NFT marketplace for pro traders. Advanced tools, zero marketplace fees, and lightning fast sweeping.",
    categories: ["NFT", "Marketplace"],
    chains: ["Ethereum"],
    twitterUrl: "https://twitter.com/blur_io",
    telegramUrl: "https://t.me/blur_io",
    websiteUrl: "https://blur.io",
    heatScore: 10900,
    sourcePlatform: "Twitter",
    createdAt: "2024-01-05",
    marketCap: "$680M",
    volume24h: "$156M",
    priceChange24h: -8.4,
    followers: { twitter: 620000, telegram: 45000 },
    tags: ["NFT", "Trading", "Pro Tools"],
    status: 'active',
  },
  {
    id: "10",
    name: "Ethereum Name Service",
    logo: "https://pbs.twimg.com/profile_images/1501560311655043073/fOJp6VIY_400x400.jpg",
    intro: "Decentralized naming for Web3",
    description: "ENS offers a secure & decentralised way to address resources both on and off the blockchain using simple, human-readable names.",
    categories: ["Infrastructure", "Identity"],
    chains: ["Ethereum"],
    twitterUrl: "https://twitter.com/ensdomains",
    telegramUrl: "https://t.me/ens_dao",
    websiteUrl: "https://ens.domains",
    heatScore: 9200,
    sourcePlatform: "Twitter",
    createdAt: "2024-01-12",
    marketCap: "$890M",
    volume24h: "$15M",
    priceChange24h: 4.1,
    followers: { twitter: 180000, telegram: 25000 },
    tags: ["Domains", "Identity", "Web3"],
    status: 'active',
  },
];

export const mockSectors: Sector[] = [
  { 
    id: "ai", 
    name: "AI", 
    heatScore: 45600, 
    projectCount: 12, 
    color: "crypto-purple",
    change24h: 15.4,
    description: "Artificial Intelligence and Machine Learning projects",
    topProjects: ["Render Network", "SingularityNET", "Ocean Protocol"]
  },
  { 
    id: "depin", 
    name: "DePIN", 
    heatScore: 38200, 
    projectCount: 8, 
    color: "crypto-blue",
    change24h: 8.7,
    description: "Decentralized Physical Infrastructure Networks",
    topProjects: ["Helium", "Hivemapper", "DIMO"]
  },
  { 
    id: "socialfi", 
    name: "SocialFi", 
    heatScore: 35900, 
    projectCount: 15, 
    color: "crypto-green",
    change24h: 22.1,
    description: "Social Finance and Decentralized Social Networks",
    topProjects: ["Friend.Tech", "Farcaster", "Lens Protocol"]
  },
  { 
    id: "defi", 
    name: "DeFi", 
    heatScore: 42100, 
    projectCount: 45, 
    color: "crypto-orange",
    change24h: 5.3,
    description: "Decentralized Finance protocols and applications",
    topProjects: ["Jupiter", "Kamino", "Aave"]
  },
  { 
    id: "zk", 
    name: "ZK", 
    heatScore: 28500, 
    projectCount: 7, 
    color: "crypto-red",
    change24h: -2.1,
    description: "Zero-Knowledge proof technology and applications",
    topProjects: ["zkSync", "Polygon zkEVM", "StarkNet"]
  },
  { 
    id: "layer2", 
    name: "Layer2", 
    heatScore: 31200, 
    projectCount: 18, 
    color: "crypto-blue",
    change24h: 12.8,
    description: "Layer 2 scaling solutions for Ethereum",
    topProjects: ["Arbitrum", "Optimism", "Base"]
  },
  { 
    id: "nft", 
    name: "NFT", 
    heatScore: 15600, 
    projectCount: 22, 
    color: "crypto-purple",
    change24h: -5.2,
    description: "Non-Fungible Tokens and digital collectibles",
    topProjects: ["Blur", "OpenSea", "Magic Eden"]
  },
  { 
    id: "gamefi", 
    name: "GameFi", 
    heatScore: 19800, 
    projectCount: 13, 
    color: "crypto-green",
    change24h: 7.9,
    description: "Gaming and Play-to-Earn applications",
    topProjects: ["Axie Infinity", "The Sandbox", "Immutable X"]
  },
  { 
    id: "memecoin", 
    name: "Memecoin", 
    heatScore: 52300, 
    projectCount: 35, 
    color: "crypto-orange",
    change24h: 45.6,
    description: "Community-driven meme cryptocurrencies",
    topProjects: ["Dogecoin", "Shiba Inu", "PEPE"]
  },
  { 
    id: "infrastructure", 
    name: "Infrastructure", 
    heatScore: 25400, 
    projectCount: 9, 
    color: "crypto-blue",
    change24h: 3.2,
    description: "Blockchain infrastructure and developer tools",
    topProjects: ["Pyth Network", "Celestia", "The Graph"]
  },
];

export const getHeatColor = (score: number): string => {
  if (score > 40000) return "heat-high";
  if (score > 20000) return "heat-medium";
  return "heat-low";
};

export const formatHeatScore = (score: number): string => {
  if (score >= 1000) {
    return `${(score / 1000).toFixed(1)}K`;
  }
  return score.toString();
};

export const formatMarketCap = (marketCap: string): string => {
  return marketCap;
};

export const formatPriceChange = (change: number): { value: string; color: string } => {
  const isPositive = change >= 0;
  return {
    value: `${isPositive ? '+' : ''}${change.toFixed(1)}%`,
    color: isPositive ? 'text-crypto-green' : 'text-crypto-red'
  };
};

export const getProjectsByCategory = (category: string): Project[] => {
  return mockProjects.filter(project => 
    project.categories.some(cat => cat.toLowerCase() === category.toLowerCase())
  );
};

export const getProjectsByChain = (chain: string): Project[] => {
  return mockProjects.filter(project => 
    project.chains.some(ch => ch.toLowerCase() === chain.toLowerCase())
  );
};

export const searchProjects = (query: string): Project[] => {
  const lowercaseQuery = query.toLowerCase();
  return mockProjects.filter(project => 
    project.name.toLowerCase().includes(lowercaseQuery) ||
    project.intro.toLowerCase().includes(lowercaseQuery) ||
    project.categories.some(cat => cat.toLowerCase().includes(lowercaseQuery)) ||
    project.chains.some(chain => chain.toLowerCase().includes(lowercaseQuery))
  );
};

export const getAllCategories = (): string[] => {
  const categories = new Set<string>();
  mockProjects.forEach(project => {
    project.categories.forEach(category => categories.add(category));
  });
  return Array.from(categories).sort();
};

export const getAllChains = (): string[] => {
  const chains = new Set<string>();
  mockProjects.forEach(project => {
    project.chains.forEach(chain => chains.add(chain));
  });
  return Array.from(chains).sort();
};
