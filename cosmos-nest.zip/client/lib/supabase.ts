import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient<Database>(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: false, // No user authentication needed for public data
  },
  realtime: {
    params: {
      eventsPerSecond: 10, // Limit real-time events for performance
    }
  }
});

// Helper functions for common operations
export const supabaseHelpers = {
  // Get all projects with real-time updates
  async getProjects() {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('heat_score', { ascending: false });
    
    if (error) {
      console.error('Error fetching projects:', error);
      return [];
    }
    
    return data || [];
  },

  // Get sectors data
  async getSectors() {
    const { data, error } = await supabase
      .from('sectors')
      .select('*')
      .order('heat_score', { ascending: false });
    
    if (error) {
      console.error('Error fetching sectors:', error);
      return [];
    }
    
    return data || [];
  },

  // Get project by ID
  async getProject(id: string) {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching project:', error);
      return null;
    }
    
    return data;
  },

  // Subscribe to real-time updates for projects
  subscribeToProjects(callback: (payload: any) => void) {
    return supabase
      .channel('projects-channel')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'projects' 
        }, 
        callback
      )
      .subscribe();
  },

  // Subscribe to real-time updates for sectors
  subscribeToSectors(callback: (payload: any) => void) {
    return supabase
      .channel('sectors-channel')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'sectors' 
        }, 
        callback
      )
      .subscribe();
  },

  // Update project heat score (for API updates)
  async updateProjectHeatScore(id: string, heatScore: number) {
    const { error } = await supabase
      .from('projects')
      .update({ 
        heat_score: heatScore,
        updated_at: new Date().toISOString()
      })
      .eq('id', id);
    
    if (error) {
      console.error('Error updating project heat score:', error);
      return false;
    }
    
    return true;
  },

  // Batch update projects from external API
  async batchUpdateProjects(projects: any[]) {
    const { error } = await supabase
      .from('projects')
      .upsert(projects, { 
        onConflict: 'id',
        ignoreDuplicates: false 
      });
    
    if (error) {
      console.error('Error batch updating projects:', error);
      return false;
    }
    
    return true;
  }
};

// Type-safe database queries
export type ProjectRow = Database['public']['Tables']['projects']['Row'];
export type SectorRow = Database['public']['Tables']['sectors']['Row'];
export type ProjectInsert = Database['public']['Tables']['projects']['Insert'];
export type SectorInsert = Database['public']['Tables']['sectors']['Insert'];
