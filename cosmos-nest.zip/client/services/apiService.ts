// HotWeb3.io API 服务层 - 完整的API接入和管理系统

import { 
  rateLimiter, 
  TokenManager, 
  generateRequestSignature, 
  SecurityLogger,
  sanitizeInput
} from "@/utils/security";

// API配置
interface ApiConfig {
  baseUrl: string;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
  apiKey?: string;
  rateLimit: {
    maxRequests: number;
    windowMs: number;
  };
}

const defaultConfig: ApiConfig = {
  baseUrl: process.env.VITE_API_BASE_URL || '/api',
  timeout: 10000,
  retryAttempts: 3,
  retryDelay: 1000,
  rateLimit: {
    maxRequests: 100,
    windowMs: 60000
  }
};

// API响应接口
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
  rateLimit?: {
    remaining: number;
    resetTime: number;
  };
}

// 错误类型
export class ApiError extends Error {
  public statusCode: number;
  public errorCode?: string;
  
  constructor(message: string, statusCode: number, errorCode?: string) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.errorCode = errorCode;
  }
}

// 主要API服务类
export class ApiService {
  private config: ApiConfig;
  private abortControllers: Map<string, AbortController> = new Map();

  constructor(config: Partial<ApiConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
  }

  // 通用请求方法
  private async request<T>(
    endpoint: string,
    options: RequestInit = {},
    requestId?: string
  ): Promise<ApiResponse<T>> {
    const url = `${this.config.baseUrl}${endpoint}`;
    const method = options.method || 'GET';
    
    // 速率限制检查
    const clientId = this.getClientId();
    if (!rateLimiter.isAllowed(clientId)) {
      throw new ApiError('Rate limit exceeded', 429, 'RATE_LIMIT_EXCEEDED');
    }

    // 创建AbortController用于取消请求
    const abortController = new AbortController();
    if (requestId) {
      this.abortControllers.set(requestId, abortController);
    }

    try {
      // 准备请求头
      const headers = new Headers(options.headers);
      
      // 添加认证头
      const accessToken = TokenManager.getAccessToken();
      if (accessToken && !TokenManager.isTokenExpired(accessToken)) {
        headers.set('Authorization', `Bearer ${accessToken}`);
      }

      // 添加API Key
      if (this.config.apiKey) {
        headers.set('X-API-Key', this.config.apiKey);
      }

      // 添加请求签名（防篡改）
      const timestamp = Date.now();
      const body = options.body ? String(options.body) : '';
      const signature = generateRequestSignature(method, url, body, timestamp, 'secret_key');
      
      headers.set('X-Timestamp', timestamp.toString());
      headers.set('X-Signature', signature);
      headers.set('Content-Type', 'application/json');

      // 发送请求
      const response = await fetch(url, {
        ...options,
        headers,
        signal: abortController.signal,
        timeout: this.config.timeout
      });

      // 清理AbortController
      if (requestId) {
        this.abortControllers.delete(requestId);
      }

      // 检查响应状态
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
        throw new ApiError(
          errorData.message || `HTTP ${response.status}`,
          response.status,
          errorData.code
        );
      }

      const data = await response.json();
      
      // 记录成功请求
      SecurityLogger.log('info', `API request successful: ${method} ${endpoint}`);
      
      return data;

    } catch (error) {
      // 清理AbortController
      if (requestId) {
        this.abortControllers.delete(requestId);
      }

      if (error instanceof ApiError) {
        SecurityLogger.log('error', `API error: ${error.message}`, {
          endpoint,
          statusCode: error.statusCode,
          errorCode: error.errorCode
        });
        throw error;
      }

      if (error.name === 'AbortError') {
        SecurityLogger.log('info', `API request cancelled: ${endpoint}`);
        throw new ApiError('Request cancelled', 0, 'REQUEST_CANCELLED');
      }

      SecurityLogger.log('error', `Network error: ${error.message}`, { endpoint });
      throw new ApiError('Network error', 0, 'NETWORK_ERROR');
    }
  }

  // 重试逻辑
  private async requestWithRetry<T>(
    endpoint: string,
    options: RequestInit = {},
    requestId?: string
  ): Promise<ApiResponse<T>> {
    let lastError: Error;

    for (let attempt = 1; attempt <= this.config.retryAttempts; attempt++) {
      try {
        return await this.request<T>(endpoint, options, requestId);
      } catch (error) {
        lastError = error;
        
        // 某些错误不应重试
        if (error instanceof ApiError) {
          if (error.statusCode === 401 || error.statusCode === 403 || error.statusCode === 404) {
            throw error;
          }
        }

        if (attempt < this.config.retryAttempts) {
          await this.delay(this.config.retryDelay * attempt);
        }
      }
    }

    throw lastError!;
  }

  // 工具方法
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private getClientId(): string {
    // 生成客户端标识符（可以基于IP、用户ID等）
    return 'client_' + (navigator.userAgent + Date.now()).slice(-16);
  }

  // 取消请求
  public cancelRequest(requestId: string): void {
    const controller = this.abortControllers.get(requestId);
    if (controller) {
      controller.abort();
      this.abortControllers.delete(requestId);
    }
  }

  // GET 请求
  public async get<T>(endpoint: string, params?: Record<string, any>, requestId?: string): Promise<ApiResponse<T>> {
    const searchParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          searchParams.append(key, String(value));
        }
      });
    }
    
    const url = searchParams.toString() ? `${endpoint}?${searchParams}` : endpoint;
    return this.requestWithRetry<T>(url, { method: 'GET' }, requestId);
  }

  // POST 请求
  public async post<T>(endpoint: string, data?: any, requestId?: string): Promise<ApiResponse<T>> {
    return this.requestWithRetry<T>(
      endpoint,
      {
        method: 'POST',
        body: JSON.stringify(data)
      },
      requestId
    );
  }

  // PUT 请求
  public async put<T>(endpoint: string, data?: any, requestId?: string): Promise<ApiResponse<T>> {
    return this.requestWithRetry<T>(
      endpoint,
      {
        method: 'PUT',
        body: JSON.stringify(data)
      },
      requestId
    );
  }

  // DELETE 请求
  public async delete<T>(endpoint: string, requestId?: string): Promise<ApiResponse<T>> {
    return this.requestWithRetry<T>(endpoint, { method: 'DELETE' }, requestId);
  }
}

// 单例API服务实例
export const apiService = new ApiService();

// 具体的API接口类
export class HotWeb3Api {
  // 获取实时统计数据
  static async getStatistics(): Promise<ApiResponse<{
    total_projects: number;
    active_sectors: number;
    today_trending: number;
    total_users: number;
    total_heat_score: number;
    most_active_sector: string;
    last_updated: string;
  }>> {
    return apiService.get('/statistics', undefined, 'get_statistics');
  }

  // 获取热门项目
  static async getTrendingProjects(params: {
    time_period?: '24h' | '7d' | '30d';
    limit?: number;
    offset?: number;
    sector?: string;
    sort_by?: 'heat_score' | 'volume' | 'change';
  } = {}): Promise<ApiResponse<{
    projects: any[];
    total_count: number;
    time_period: string;
    last_updated: string;
  }>> {
    return apiService.get('/trending', params, 'get_trending');
  }

  // 获取板块热度图
  static async getSectorHeatmap(time_period: '24h' | '7d' | '30d' = '24h'): Promise<ApiResponse<{
    sectors: any[];
    time_period: string;
    last_updated: string;
  }>> {
    return apiService.get('/sectors', { time_period }, 'get_sectors');
  }

  // 搜索项目
  static async searchProjects(params: {
    q?: string;
    sectors?: string;
    chains?: string;
    limit?: number;
    offset?: number;
  }): Promise<ApiResponse<{
    projects: any[];
    total_count: number;
    facets: {
      sectors: { name: string; count: number }[];
      chains: { name: string; count: number }[];
    };
  }>> {
    // 清理搜索输入
    if (params.q) {
      params.q = sanitizeInput(params.q);
    }
    
    return apiService.get('/search', params, 'search_projects');
  }

  // 获取项目详情
  static async getProjectDetail(projectId: string): Promise<ApiResponse<{
    project: any;
    comments: any[];
    average_rating: number;
    total_comments: number;
    gpt_analysis: {
      summary: string;
      strengths: string[];
      risks: string[];
      market_potential: 'low' | 'medium' | 'high';
      confidence_score: number;
    };
  }>> {
    const cleanId = sanitizeInput(projectId);
    return apiService.get(`/project/${cleanId}`, undefined, `get_project_${cleanId}`);
  }

  // 添加项目评论
  static async addComment(projectId: string, comment: string, rating?: number): Promise<ApiResponse<{
    comment_id: string;
    message: string;
  }>> {
    const cleanComment = sanitizeInput(comment);
    const cleanId = sanitizeInput(projectId);
    
    return apiService.post(`/project/${cleanId}/comment`, {
      comment: cleanComment,
      rating
    }, `add_comment_${cleanId}`);
  }

  // 获取用户收藏的项目
  static async getFavoriteProjects(): Promise<ApiResponse<{
    projects: any[];
    total_count: number;
  }>> {
    return apiService.get('/user/favorites', undefined, 'get_favorites');
  }

  // 添加/移除收藏
  static async toggleFavorite(projectId: string): Promise<ApiResponse<{
    is_favorite: boolean;
    message: string;
  }>> {
    const cleanId = sanitizeInput(projectId);
    return apiService.post(`/user/favorite/${cleanId}`, undefined, `toggle_favorite_${cleanId}`);
  }

  // 获取API使用统计
  static async getApiUsage(): Promise<ApiResponse<{
    requests_today: number;
    requests_this_month: number;
    rate_limit_remaining: number;
    next_reset: string;
  }>> {
    return apiService.get('/user/api-usage', undefined, 'get_api_usage');
  }

  // 订阅热度提醒
  static async subscribeAlerts(settings: {
    email?: string;
    telegram?: string;
    sectors?: string[];
    min_heat_score?: number;
    frequency?: 'realtime' | 'hourly' | 'daily';
  }): Promise<ApiResponse<{
    subscription_id: string;
    message: string;
  }>> {
    return apiService.post('/user/subscribe-alerts', settings, 'subscribe_alerts');
  }

  // 获取市场数据
  static async getMarketData(symbols: string[]): Promise<ApiResponse<{
    data: Array<{
      symbol: string;
      price: number;
      change_24h: number;
      volume_24h: number;
      market_cap: number;
    }>;
    last_updated: string;
  }>> {
    return apiService.get('/market-data', { symbols: symbols.join(',') }, 'get_market_data');
  }

  // 导出数据
  static async exportData(format: 'csv' | 'json' | 'xlsx', filters?: any): Promise<ApiResponse<{
    download_url: string;
    expires_at: string;
    file_size: number;
  }>> {
    return apiService.post('/export', { format, filters }, 'export_data');
  }
}

// WebSocket连接管理
export class WebSocketManager {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private listeners: Map<string, Function[]> = new Map();

  connect(url: string = 'wss://api.hotweb3.io/ws'): void {
    try {
      this.ws = new WebSocket(url);
      
      this.ws.onopen = () => {
        SecurityLogger.log('info', 'WebSocket connected');
        this.reconnectAttempts = 0;
        this.emit('connected', null);
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.emit(data.type, data.payload);
        } catch (error) {
          SecurityLogger.log('error', 'WebSocket message parse error', error);
        }
      };

      this.ws.onclose = () => {
        SecurityLogger.log('warn', 'WebSocket disconnected');
        this.emit('disconnected', null);
        this.attemptReconnect();
      };

      this.ws.onerror = (error) => {
        SecurityLogger.log('error', 'WebSocket error', error);
        this.emit('error', error);
      };

    } catch (error) {
      SecurityLogger.log('error', 'WebSocket connection failed', error);
    }
  }

  private attemptReconnect(): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      setTimeout(() => {
        SecurityLogger.log('info', `WebSocket reconnect attempt ${this.reconnectAttempts}`);
        this.connect();
      }, this.reconnectDelay * this.reconnectAttempts);
    }
  }

  subscribe(channel: string, callback: Function): void {
    if (!this.listeners.has(channel)) {
      this.listeners.set(channel, []);
    }
    this.listeners.get(channel)!.push(callback);

    // 发送订阅消息
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        action: 'subscribe',
        channel
      }));
    }
  }

  unsubscribe(channel: string, callback?: Function): void {
    if (callback) {
      const callbacks = this.listeners.get(channel) || [];
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    } else {
      this.listeners.delete(channel);
    }

    // 发送取消订阅消息
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        action: 'unsubscribe',
        channel
      }));
    }
  }

  private emit(event: string, data: any): void {
    const callbacks = this.listeners.get(event) || [];
    callbacks.forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        SecurityLogger.log('error', 'WebSocket callback error', error);
      }
    });
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.listeners.clear();
  }
}

// 单例WebSocket管理器
export const wsManager = new WebSocketManager();

// 错误处理Hook
export function useApiErrorHandler() {
  const handleError = (error: ApiError) => {
    switch (error.statusCode) {
      case 401:
        // 未授权，清除tokens并重定向到登录
        TokenManager.clearTokens();
        // window.location.href = '/login';
        break;
      case 403:
        // 禁止访问
        alert('您没有权限执行此操作');
        break;
      case 429:
        // 速率限制
        alert('请求过于频繁，请稍后再试');
        break;
      case 500:
        // 服务器错误
        alert('服务器暂时不可���，请稍后重试');
        break;
      default:
        alert(error.message || '请求失败，请重试');
    }
  };

  return { handleError };
}
