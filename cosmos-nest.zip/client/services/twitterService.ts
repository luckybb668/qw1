interface TwitterMetrics {
  followersCount: number;
  mentions24h: number;
  engagementRate: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  trendingScore: number;
}

interface TwitterApiResponse {
  data: {
    public_metrics: {
      followers_count: number;
      following_count: number;
      tweet_count: number;
      listed_count: number;
    };
    name: string;
    username: string;
    verified: boolean;
  };
  meta?: {
    result_count: number;
  };
}

class TwitterService {
  private readonly baseUrl = 'https://api.twitter.com/2';
  private readonly bearerToken = import.meta.env.VITE_TWITTER_BEARER_TOKEN;
  
  constructor() {
    if (!this.bearerToken) {
      console.warn('Twitter Bearer Token not found. Twitter integration will use mock data.');
    }
  }

  private async makeRequest(endpoint: string): Promise<any> {
    if (!this.bearerToken) {
      throw new Error('Twitter Bearer Token not configured');
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${this.bearerToken}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Twitter API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async getUserByUsername(username: string): Promise<TwitterApiResponse | null> {
    try {
      const cleanUsername = username.replace('@', '').replace('https://twitter.com/', '').replace('https://x.com/', '');
      return await this.makeRequest(`/users/by/username/${cleanUsername}?user.fields=public_metrics,verified`);
    } catch (error) {
      console.error('Error fetching Twitter user:', error);
      return null;
    }
  }

  async searchMentions(query: string, maxResults: number = 100): Promise<any> {
    try {
      const encodedQuery = encodeURIComponent(query);
      return await this.makeRequest(`/tweets/search/recent?query=${encodedQuery}&max_results=${maxResults}&tweet.fields=public_metrics,created_at`);
    } catch (error) {
      console.error('Error searching Twitter mentions:', error);
      return null;
    }
  }

  async getProjectMetrics(projectName: string, twitterUsername?: string): Promise<TwitterMetrics> {
    try {
      // Get user data if username provided
      let userMetrics = null;
      if (twitterUsername) {
        const username = this.extractUsername(twitterUsername);
        userMetrics = await this.getUserByUsername(username);
      }

      // Search for recent mentions
      const mentionsData = await this.searchMentions(`"${projectName}" crypto OR blockchain`, 100);
      
      // Calculate metrics
      const followersCount = userMetrics?.data?.public_metrics?.followers_count || 0;
      const mentions24h = mentionsData?.meta?.result_count || 0;
      
      // Simple engagement rate calculation (mentions per 1000 followers)
      const engagementRate = followersCount > 0 ? (mentions24h / followersCount) * 1000 : 0;
      
      // Simple sentiment analysis based on engagement
      const sentiment: 'positive' | 'neutral' | 'negative' = 
        engagementRate > 10 ? 'positive' : 
        engagementRate > 5 ? 'neutral' : 'negative';
      
      // Trending score based on mentions and engagement
      const trendingScore = Math.min(100, mentions24h * 2 + engagementRate * 10);

      return {
        followersCount,
        mentions24h,
        engagementRate: Math.round(engagementRate * 100) / 100,
        sentiment,
        trendingScore: Math.round(trendingScore)
      };

    } catch (error) {
      console.error('Error getting project metrics:', error);
      // Return mock data on error
      return this.getMockMetrics(projectName);
    }
  }

  private extractUsername(url: string): string {
    if (url.includes('twitter.com/') || url.includes('x.com/')) {
      return url.split('/').pop() || '';
    }
    return url.replace('@', '');
  }

  private getMockMetrics(projectName: string): TwitterMetrics {
    // Generate realistic mock data based on project name hash
    const hash = projectName.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    
    return {
      followersCount: Math.floor((hash % 500000) + 10000),
      mentions24h: Math.floor((hash % 100) + 10),
      engagementRate: Math.round(((hash % 20) + 5) * 100) / 100,
      sentiment: hash % 3 === 0 ? 'positive' : hash % 3 === 1 ? 'neutral' : 'negative',
      trendingScore: Math.floor((hash % 80) + 20)
    };
  }

  // Batch process multiple projects
  async batchGetMetrics(projects: Array<{ name: string; twitterUrl?: string }>): Promise<Map<string, TwitterMetrics>> {
    const results = new Map<string, TwitterMetrics>();
    
    // Process in batches to avoid rate limiting
    const batchSize = 5;
    for (let i = 0; i < projects.length; i += batchSize) {
      const batch = projects.slice(i, i + batchSize);
      
      const batchPromises = batch.map(async (project) => {
        const metrics = await this.getProjectMetrics(project.name, project.twitterUrl);
        return { name: project.name, metrics };
      });
      
      const batchResults = await Promise.all(batchPromises);
      
      batchResults.forEach(({ name, metrics }) => {
        results.set(name, metrics);
      });
      
      // Add delay between batches to respect rate limits
      if (i + batchSize < projects.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    return results;
  }

  // Real-time metrics update for a single project
  async startRealTimeUpdates(projectName: string, twitterUsername: string, callback: (metrics: TwitterMetrics) => void): Promise<() => void> {
    const updateInterval = setInterval(async () => {
      try {
        const metrics = await this.getProjectMetrics(projectName, twitterUsername);
        callback(metrics);
      } catch (error) {
        console.error('Error in real-time update:', error);
      }
    }, 5 * 60 * 1000); // Update every 5 minutes

    // Return cleanup function
    return () => clearInterval(updateInterval);
  }
}

export const twitterService = new TwitterService();

// Helper functions for heat score calculation
export function calculateHeatScoreFromTwitter(metrics: TwitterMetrics): number {
  // Weighted calculation based on various Twitter metrics
  const followersWeight = 0.3;
  const mentionsWeight = 0.4;
  const engagementWeight = 0.3;
  
  const followersScore = Math.min(100, (metrics.followersCount / 10000) * 100);
  const mentionsScore = Math.min(100, metrics.mentions24h * 5);
  const engagementScore = Math.min(100, metrics.engagementRate * 10);
  
  return Math.round(
    followersScore * followersWeight +
    mentionsScore * mentionsWeight +
    engagementScore * engagementWeight
  );
}

export function combineMetricsToHeatScore(twitterMetrics: TwitterMetrics, baseHeatScore: number): number {
  const twitterHeat = calculateHeatScoreFromTwitter(twitterMetrics);
  
  // Combine Twitter metrics with base heat score (70% base, 30% Twitter)
  return Math.round(baseHeatScore * 0.7 + twitterHeat * 0.3);
}
