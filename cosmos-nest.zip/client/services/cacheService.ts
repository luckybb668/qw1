interface CacheItem<T> {
  data: T;
  timestamp: number;
  ttl: number; // Time to live in milliseconds
}

interface CacheConfig {
  defaultTTL: number;
  maxSize: number;
  persistToStorage: boolean;
}

class CacheService {
  private cache = new Map<string, CacheItem<any>>();
  private config: CacheConfig;
  private storageKey = 'hotweb3_cache';

  constructor(config: Partial<CacheConfig> = {}) {
    this.config = {
      defaultTTL: 5 * 60 * 1000, // 5 minutes default
      maxSize: 100, // Maximum number of cached items
      persistToStorage: true,
      ...config
    };

    if (this.config.persistToStorage) {
      this.loadFromStorage();
    }

    // Clean up expired items periodically
    setInterval(() => this.cleanup(), 60 * 1000); // Every minute
  }

  set<T>(key: string, data: T, ttl?: number): void {
    const item: CacheItem<T> = {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.config.defaultTTL
    };

    // Enforce max size
    if (this.cache.size >= this.config.maxSize) {
      const oldestKey = this.getOldestKey();
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }

    this.cache.set(key, item);

    if (this.config.persistToStorage) {
      this.saveToStorage();
    }
  }

  get<T>(key: string): T | null {
    const item = this.cache.get(key);
    
    if (!item) {
      return null;
    }

    // Check if item has expired
    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key);
      if (this.config.persistToStorage) {
        this.saveToStorage();
      }
      return null;
    }

    return item.data;
  }

  has(key: string): boolean {
    return this.get(key) !== null;
  }

  delete(key: string): boolean {
    const deleted = this.cache.delete(key);
    if (deleted && this.config.persistToStorage) {
      this.saveToStorage();
    }
    return deleted;
  }

  clear(): void {
    this.cache.clear();
    if (this.config.persistToStorage) {
      localStorage.removeItem(this.storageKey);
    }
  }

  // Get or set pattern for easier usage
  async getOrSet<T>(
    key: string, 
    fetchFunction: () => Promise<T>, 
    ttl?: number
  ): Promise<T> {
    const cached = this.get<T>(key);
    if (cached !== null) {
      return cached;
    }

    const data = await fetchFunction();
    this.set(key, data, ttl);
    return data;
  }

  // Invalidate cache entries by pattern
  invalidatePattern(pattern: string): void {
    const regex = new RegExp(pattern);
    const keysToDelete: string[] = [];

    for (const key of this.cache.keys()) {
      if (regex.test(key)) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach(key => this.delete(key));
  }

  private cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];

    for (const [key, item] of this.cache.entries()) {
      if (now - item.timestamp > item.ttl) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach(key => this.cache.delete(key));

    if (keysToDelete.length > 0 && this.config.persistToStorage) {
      this.saveToStorage();
    }
  }

  private getOldestKey(): string | null {
    let oldestKey = null;
    let oldestTime = Infinity;

    for (const [key, item] of this.cache.entries()) {
      if (item.timestamp < oldestTime) {
        oldestTime = item.timestamp;
        oldestKey = key;
      }
    }

    return oldestKey;
  }

  private saveToStorage(): void {
    try {
      const serialized = JSON.stringify(Array.from(this.cache.entries()));
      localStorage.setItem(this.storageKey, serialized);
    } catch (error) {
      console.warn('Failed to save cache to localStorage:', error);
    }
  }

  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const entries = JSON.parse(stored);
        this.cache = new Map(entries);
        // Clean up any expired items from storage
        this.cleanup();
      }
    } catch (error) {
      console.warn('Failed to load cache from localStorage:', error);
    }
  }

  // Get cache statistics
  getStats() {
    const now = Date.now();
    let expired = 0;
    let valid = 0;

    for (const item of this.cache.values()) {
      if (now - item.timestamp > item.ttl) {
        expired++;
      } else {
        valid++;
      }
    }

    return {
      total: this.cache.size,
      valid,
      expired,
      maxSize: this.config.maxSize,
      defaultTTL: this.config.defaultTTL
    };
  }
}

// Create different cache instances for different data types
export const projectsCache = new CacheService({
  defaultTTL: 2 * 60 * 1000, // 2 minutes for projects (more dynamic)
  maxSize: 50,
  persistToStorage: true
});

export const sectorsCache = new CacheService({
  defaultTTL: 5 * 60 * 1000, // 5 minutes for sectors
  maxSize: 20,
  persistToStorage: true
});

export const twitterCache = new CacheService({
  defaultTTL: 10 * 60 * 1000, // 10 minutes for Twitter data
  maxSize: 100,
  persistToStorage: true
});

export const apiCache = new CacheService({
  defaultTTL: 3 * 60 * 1000, // 3 minutes for general API calls
  maxSize: 200,
  persistToStorage: false // API cache shouldn't persist across sessions
});

// Helper functions for common caching patterns
export const cacheKeys = {
  projects: () => 'projects:all',
  project: (id: string) => `project:${id}`,
  sectors: () => 'sectors:all',
  sector: (id: string) => `sector:${id}`,
  twitterMetrics: (projectName: string) => `twitter:${projectName}`,
  searchResults: (query: string) => `search:${query}`,
  heatHistory: (projectId: string, timeframe: string) => `heat:${projectId}:${timeframe}`
};

// Cache warming functions
export async function warmProjectsCache(fetchFunction: () => Promise<any[]>) {
  try {
    const projects = await fetchFunction();
    projectsCache.set(cacheKeys.projects(), projects, 5 * 60 * 1000); // 5 minutes
    
    // Cache individual projects
    projects.forEach(project => {
      projectsCache.set(cacheKeys.project(project.id), project, 10 * 60 * 1000); // 10 minutes
    });
    
    console.log('Projects cache warmed successfully');
  } catch (error) {
    console.error('Failed to warm projects cache:', error);
  }
}

export async function warmSectorsCache(fetchFunction: () => Promise<any[]>) {
  try {
    const sectors = await fetchFunction();
    sectorsCache.set(cacheKeys.sectors(), sectors, 10 * 60 * 1000); // 10 minutes
    
    console.log('Sectors cache warmed successfully');
  } catch (error) {
    console.error('Failed to warm sectors cache:', error);
  }
}

// Cache invalidation helpers
export function invalidateProjectCache(projectId?: string) {
  if (projectId) {
    projectsCache.delete(cacheKeys.project(projectId));
  } else {
    projectsCache.invalidatePattern('^project:');
  }
  projectsCache.delete(cacheKeys.projects());
}

export function invalidateSectorCache(sectorId?: string) {
  if (sectorId) {
    sectorsCache.delete(cacheKeys.sector(sectorId));
  } else {
    sectorsCache.invalidatePattern('^sector:');
  }
  sectorsCache.delete(cacheKeys.sectors());
}

// Export the base CacheService for custom instances
export { CacheService };
