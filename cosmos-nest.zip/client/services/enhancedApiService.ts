// Enhanced API Service with Supabase, Twitter, and caching integration
import { supabaseHelpers } from "@/lib/supabase";
import { twitterService, combineMetricsToHeatScore } from "./twitterService";
import { 
  projectsCache, 
  sectorsCache, 
  twitterCache, 
  apiCache, 
  cacheKeys, 
  warmProjectsCache, 
  warmSectorsCache,
  invalidateProjectCache,
  invalidateSectorCache
} from "./cacheService";
import { transformSupabaseProject, transformSupabaseSector } from "@/types/database";
import { mockProjects, mockSectors, type Project, type Sector } from "@/data/mockData";

interface EnhancedApiConfig {
  useSupabase: boolean;
  useTwitter: boolean;
  useCaching: boolean;
  offlineMode: boolean;
  realTimeUpdates: boolean;
}

class EnhancedApiService {
  private config: EnhancedApiConfig;
  private realTimeSubscriptions = new Map<string, any>();

  constructor(config: Partial<EnhancedApiConfig> = {}) {
    this.config = {
      useSupabase: true,
      useTwitter: true,
      useCaching: true,
      offlineMode: false,
      realTimeUpdates: true,
      ...config
    };

    // Initialize cache warming
    if (this.config.useCaching) {
      this.initializeCaches();
    }

    // Setup real-time subscriptions
    if (this.config.realTimeUpdates) {
      this.setupRealTimeUpdates();
    }
  }

  private async initializeCaches() {
    try {
      await Promise.all([
        warmProjectsCache(() => this.loadProjectsFromSource()),
        warmSectorsCache(() => this.loadSectorsFromSource())
      ]);
    } catch (error) {
      console.warn('Cache initialization failed:', error);
    }
  }

  private setupRealTimeUpdates() {
    if (!this.config.useSupabase) return;

    // Subscribe to projects updates
    const projectsSubscription = supabaseHelpers.subscribeToProjects((payload) => {
      console.log('Real-time project update received:', payload);
      invalidateProjectCache();
      this.refreshProjectsCache();
    });

    // Subscribe to sectors updates
    const sectorsSubscription = supabaseHelpers.subscribeToSectors((payload) => {
      console.log('Real-time sector update received:', payload);
      invalidateSectorCache();
      this.refreshSectorsCache();
    });

    this.realTimeSubscriptions.set('projects', projectsSubscription);
    this.realTimeSubscriptions.set('sectors', sectorsSubscription);
  }

  // Load projects from best available source
  private async loadProjectsFromSource(): Promise<Project[]> {
    if (this.config.offlineMode) {
      return mockProjects;
    }

    if (this.config.useSupabase) {
      try {
        const supabaseProjects = await supabaseHelpers.getProjects();
        if (supabaseProjects.length > 0) {
          return supabaseProjects.map(transformSupabaseProject);
        }
      } catch (error) {
        console.warn('Supabase projects fetch failed:', error);
      }
    }

    // Fallback to mock data
    return mockProjects;
  }

  // Load sectors from best available source
  private async loadSectorsFromSource(): Promise<Sector[]> {
    if (this.config.offlineMode) {
      return mockSectors;
    }

    if (this.config.useSupabase) {
      try {
        const supabaseSectors = await supabaseHelpers.getSectors();
        if (supabaseSectors.length > 0) {
          return supabaseSectors.map(transformSupabaseSector);
        }
      } catch (error) {
        console.warn('Supabase sectors fetch failed:', error);
      }
    }

    // Fallback to mock data
    return mockSectors;
  }

  // Get all projects with caching and Twitter enhancement
  async getProjects(refresh = false): Promise<Project[]> {
    const cacheKey = cacheKeys.projects();

    // Check cache first (unless refresh is requested)
    if (!refresh && this.config.useCaching && projectsCache.has(cacheKey)) {
      const cached = projectsCache.get<Project[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      // Load from source
      let projects = await this.loadProjectsFromSource();

      // Enhance with Twitter data if enabled
      if (this.config.useTwitter && projects.length > 0) {
        projects = await this.enhanceProjectsWithTwitter(projects);
      }

      // Cache the results
      if (this.config.useCaching) {
        projectsCache.set(cacheKey, projects, 2 * 60 * 1000); // 2 minutes cache
      }

      return projects;

    } catch (error) {
      console.error('Error fetching projects:', error);
      return mockProjects; // Always fallback to mock data
    }
  }

  // Get single project with caching
  async getProject(id: string, refresh = false): Promise<Project | null> {
    const cacheKey = cacheKeys.project(id);

    // Check cache first
    if (!refresh && this.config.useCaching && projectsCache.has(cacheKey)) {
      const cached = projectsCache.get<Project>(cacheKey);
      if (cached) return cached;
    }

    try {
      if (this.config.useSupabase) {
        const supabaseProject = await supabaseHelpers.getProject(id);
        if (supabaseProject) {
          let project = transformSupabaseProject(supabaseProject);

          // Enhance with Twitter data
          if (this.config.useTwitter && project.twitterUrl) {
            project = await this.enhanceProjectWithTwitter(project);
          }

          // Cache the result
          if (this.config.useCaching) {
            projectsCache.set(cacheKey, project, 10 * 60 * 1000); // 10 minutes cache
          }

          return project;
        }
      }

      // Fallback to mock data
      const mockProject = mockProjects.find(p => p.id === id);
      if (mockProject && this.config.useCaching) {
        projectsCache.set(cacheKey, mockProject, 10 * 60 * 1000);
      }
      return mockProject || null;

    } catch (error) {
      console.error('Error fetching project:', error);
      return mockProjects.find(p => p.id === id) || null;
    }
  }

  // Get all sectors with caching
  async getSectors(refresh = false): Promise<Sector[]> {
    const cacheKey = cacheKeys.sectors();

    // Check cache first
    if (!refresh && this.config.useCaching && sectorsCache.has(cacheKey)) {
      const cached = sectorsCache.get<Sector[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      const sectors = await this.loadSectorsFromSource();

      // Cache the results
      if (this.config.useCaching) {
        sectorsCache.set(cacheKey, sectors, 5 * 60 * 1000); // 5 minutes cache
      }

      return sectors;

    } catch (error) {
      console.error('Error fetching sectors:', error);
      return mockSectors;
    }
  }

  // Search projects with caching
  async searchProjects(query: string, filters?: {
    categories?: string[];
    chains?: string[];
    status?: string;
  }): Promise<Project[]> {
    const cacheKey = cacheKeys.searchResults(query + JSON.stringify(filters));

    // Check cache first
    if (this.config.useCaching && apiCache.has(cacheKey)) {
      const cached = apiCache.get<Project[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      const projects = await this.getProjects();
      
      // Apply search and filters
      let filtered = projects.filter(project => {
        const matchesQuery = !query || 
          project.name.toLowerCase().includes(query.toLowerCase()) ||
          project.intro.toLowerCase().includes(query.toLowerCase()) ||
          project.description.toLowerCase().includes(query.toLowerCase());

        const matchesCategory = !filters?.categories?.length ||
          filters.categories.some(cat => project.categories.includes(cat));

        const matchesChain = !filters?.chains?.length ||
          filters.chains.some(chain => project.chains.includes(chain));

        const matchesStatus = !filters?.status || project.status === filters.status;

        return matchesQuery && matchesCategory && matchesChain && matchesStatus;
      });

      // Sort by heat score
      filtered = filtered.sort((a, b) => b.heatScore - a.heatScore);

      // Cache results
      if (this.config.useCaching) {
        apiCache.set(cacheKey, filtered, 3 * 60 * 1000); // 3 minutes cache
      }

      return filtered;

    } catch (error) {
      console.error('Error searching projects:', error);
      return [];
    }
  }

  // Enhance projects with Twitter metrics
  private async enhanceProjectsWithTwitter(projects: Project[]): Promise<Project[]> {
    try {
      const projectsWithTwitter = projects.filter(p => p.twitterUrl);
      
      if (projectsWithTwitter.length === 0) return projects;

      // Batch fetch Twitter metrics
      const twitterMetrics = await twitterService.batchGetMetrics(
        projectsWithTwitter.map(p => ({ name: p.name, twitterUrl: p.twitterUrl }))
      );

      // Apply metrics to projects
      return projects.map(project => {
        const metrics = twitterMetrics.get(project.name);
        if (metrics) {
          return {
            ...project,
            heatScore: combineMetricsToHeatScore(metrics, project.heatScore),
            followers: {
              ...project.followers,
              twitter: metrics.followersCount
            }
          };
        }
        return project;
      });

    } catch (error) {
      console.error('Error enhancing projects with Twitter data:', error);
      return projects;
    }
  }

  // Enhance single project with Twitter metrics
  private async enhanceProjectWithTwitter(project: Project): Promise<Project> {
    if (!project.twitterUrl) return project;

    const cacheKey = cacheKeys.twitterMetrics(project.name);

    try {
      // Check Twitter cache first
      let metrics = this.config.useCaching ? twitterCache.get(cacheKey) : null;

      if (!metrics) {
        metrics = await twitterService.getProjectMetrics(project.name, project.twitterUrl);
        
        if (this.config.useCaching) {
          twitterCache.set(cacheKey, metrics, 10 * 60 * 1000); // 10 minutes cache
        }
      }

      return {
        ...project,
        heatScore: combineMetricsToHeatScore(metrics, project.heatScore),
        followers: {
          ...project.followers,
          twitter: metrics.followersCount
        }
      };

    } catch (error) {
      console.error('Error enhancing project with Twitter data:', error);
      return project;
    }
  }

  // Update project heat score in database
  async updateProjectHeatScore(projectId: string, newHeatScore: number): Promise<boolean> {
    if (!this.config.useSupabase) return false;

    try {
      const success = await supabaseHelpers.updateProjectHeatScore(projectId, newHeatScore);
      
      if (success) {
        // Invalidate caches
        invalidateProjectCache(projectId);
        invalidateProjectCache(); // Also invalidate the projects list
      }

      return success;

    } catch (error) {
      console.error('Error updating project heat score:', error);
      return false;
    }
  }

  // Batch update projects from external APIs
  async batchUpdateProjects(projects: Project[]): Promise<boolean> {
    if (!this.config.useSupabase) return false;

    try {
      // Transform to Supabase format
      const supabaseProjects = projects.map(project => ({
        id: project.id,
        name: project.name,
        logo: project.logo,
        intro: project.intro,
        description: project.description,
        categories: project.categories,
        chains: project.chains,
        twitter_url: project.twitterUrl,
        telegram_url: project.telegramUrl,
        discord_url: project.discordUrl,
        website_url: project.websiteUrl,
        heat_score: project.heatScore,
        source_platform: project.sourcePlatform,
        created_at: project.createdAt,
        market_cap: project.marketCap,
        volume_24h: project.volume24h,
        price_change_24h: project.priceChange24h,
        followers: project.followers as any,
        tags: project.tags,
        status: project.status,
        updated_at: new Date().toISOString(),
      }));

      const success = await supabaseHelpers.batchUpdateProjects(supabaseProjects);
      
      if (success) {
        // Clear all project caches
        invalidateProjectCache();
      }

      return success;

    } catch (error) {
      console.error('Error batch updating projects:', error);
      return false;
    }
  }

  // Refresh caches manually
  async refreshProjectsCache(): Promise<void> {
    await this.getProjects(true);
  }

  async refreshSectorsCache(): Promise<void> {
    await this.getSectors(true);
  }

  // Setup real-time updates for a specific project
  async setupProjectRealTimeUpdates(projectId: string, callback: (project: Project) => void): Promise<() => void> {
    const project = await this.getProject(projectId);
    if (!project?.twitterUrl) {
      return () => {}; // No cleanup needed
    }

    // Start Twitter real-time updates
    const cleanup = await twitterService.startRealTimeUpdates(
      project.name,
      project.twitterUrl,
      async (metrics) => {
        const updatedHeatScore = combineMetricsToHeatScore(metrics, project.heatScore);
        
        // Update project with new data
        const updatedProject = {
          ...project,
          heatScore: updatedHeatScore,
          followers: {
            ...project.followers,
            twitter: metrics.followersCount
          }
        };

        // Update database if possible
        if (this.config.useSupabase) {
          await this.updateProjectHeatScore(projectId, updatedHeatScore);
        }

        // Call the callback with updated project
        callback(updatedProject);
      }
    );

    return cleanup;
  }

  // Get service statistics
  getServiceStats() {
    return {
      config: this.config,
      cacheStats: {
        projects: projectsCache.getStats(),
        sectors: sectorsCache.getStats(),
        twitter: twitterCache.getStats(),
        api: apiCache.getStats(),
      },
      realTimeSubscriptions: Array.from(this.realTimeSubscriptions.keys()),
    };
  }

  // Cleanup method
  cleanup(): void {
    // Unsubscribe from real-time updates
    this.realTimeSubscriptions.forEach(subscription => {
      if (subscription && typeof subscription.unsubscribe === 'function') {
        subscription.unsubscribe();
      }
    });
    this.realTimeSubscriptions.clear();
  }
}

// Create and export enhanced API service instance
export const enhancedApiService = new EnhancedApiService();

// Export types and utilities
export type { EnhancedApiConfig };
export { EnhancedApiService };
