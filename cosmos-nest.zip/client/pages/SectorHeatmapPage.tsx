import { useState } from "react";
import { TrendingUp, TrendingDown, Activity, BarChart3, PieChart, Filter } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { mockSectors, mockProjects, formatHeatScore, getProjectsByCategory, type Sector } from "@/data/mockData";
import { ExportDialog } from "@/components/ExportDialog";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

type ViewMode = 'heatmap' | 'list' | 'chart';
type TimeFilter = '24h' | '7d' | '30d';

export default function SectorHeatmapPage() {
  const [viewMode, setViewMode] = useState<ViewMode>('heatmap');
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('24h');
  const [selectedSector, setSelectedSector] = useState<Sector | null>(null);

  const sortedSectors = [...mockSectors].sort((a, b) => b.heatScore - a.heatScore);
  const topMovers = sortedSectors.filter(sector => Math.abs(sector.change24h) > 10);

  const getHeatIntensity = (score: number) => {
    const maxScore = Math.max(...mockSectors.map((s) => s.heatScore));
    const intensity = score / maxScore;
    
    if (intensity > 0.8) return "high";
    if (intensity > 0.5) return "medium";
    return "low";
  };

  const getHeatOpacity = (score: number) => {
    const maxScore = Math.max(...mockSectors.map((s) => s.heatScore));
    const intensity = score / maxScore;
    return Math.max(0.3, intensity);
  };

  const SectorHeatmapCard = ({ sector }: { sector: Sector }) => {
    const heatLevel = getHeatIntensity(sector.heatScore);
    const opacity = getHeatOpacity(sector.heatScore);
    const sectorProjects = getProjectsByCategory(sector.name);
    
    return (
      <Card
        className={cn(
          "group cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl border-border relative overflow-hidden",
          "hover:border-crypto-green/50"
        )}
        style={{
          background: `linear-gradient(135deg, 
            hsla(var(--${sector.color}), ${opacity}) 0%, 
            hsla(var(--${sector.color}), ${opacity * 0.6}) 100%)`,
        }}
        onClick={() => setSelectedSector(sector)}
      >
        <CardContent className="p-6 relative z-10">
          <div className="text-center">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-foreground text-lg group-hover:text-crypto-green transition-colors">
                {sector.name}
              </h3>
              <div className={cn(
                "text-xs px-2 py-1 rounded-full",
                sector.change24h >= 0 ? "bg-crypto-green/20 text-crypto-green" : "bg-crypto-red/20 text-crypto-red"
              )}>
                {sector.change24h >= 0 ? <TrendingUp className="h-3 w-3 inline mr-1" /> : <TrendingDown className="h-3 w-3 inline mr-1" />}
                {Math.abs(sector.change24h)}%
              </div>
            </div>
            
            <div className="flex items-center justify-center space-x-1 mb-2">
              <Activity className="h-4 w-4 text-crypto-green" />
              <span className="text-xl font-bold text-foreground">
                {formatHeatScore(sector.heatScore)}
              </span>
            </div>
            
            <div className="text-sm text-muted-foreground mb-3">
              {sector.projectCount} projects
            </div>
            
            <div className="mt-3 w-full bg-border/30 rounded-full h-2 overflow-hidden">
              <div
                className={cn("h-full rounded-full transition-all duration-500", `bg-${sector.color}`)}
                style={{ width: `${opacity * 100}%` }}
              />
            </div>

            <p className="text-xs text-muted-foreground mt-3 line-clamp-2">
              {sector.description}
            </p>
          </div>
        </CardContent>
        
        <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </Card>
    );
  };

  const SectorListItem = ({ sector }: { sector: Sector }) => (
    <Card className="hover:shadow-md transition-all duration-300 border-border bg-card">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1">
            <div 
              className={cn("w-12 h-12 rounded-lg flex items-center justify-center", `bg-${sector.color}/20`)}
            >
              <Activity className={cn("h-6 w-6", `text-${sector.color}`)} />
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3">
                <h3 className="font-semibold text-foreground hover:text-crypto-green transition-colors cursor-pointer">
                  {sector.name}
                </h3>
                <Badge 
                  variant={sector.change24h >= 0 ? "default" : "destructive"}
                  className={sector.change24h >= 0 ? "bg-crypto-green text-white" : ""}
                >
                  {sector.change24h >= 0 ? "+" : ""}{sector.change24h}%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{sector.description}</p>
            </div>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div className="text-center">
              <div className="text-crypto-green font-semibold">{formatHeatScore(sector.heatScore)}</div>
              <div className="text-xs text-muted-foreground">Heat Score</div>
            </div>
            
            <div className="text-center">
              <div className="font-semibold">{sector.projectCount}</div>
              <div className="text-xs text-muted-foreground">Projects</div>
            </div>

            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setSelectedSector(sector)}
            >
              View Details
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-crypto-purple to-crypto-blue flex items-center justify-center">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Sector Heatmap</h1>
          </div>
          <p className="text-muted-foreground">
            Real-time industry activity and trending sectors across Web3
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-foreground">{mockSectors.length}</div>
              <div className="text-sm text-muted-foreground">Total Sectors</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-crypto-green">
                {formatHeatScore(Math.max(...mockSectors.map(s => s.heatScore)))}
              </div>
              <div className="text-sm text-muted-foreground">Highest Heat</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-foreground">
                {mockSectors.reduce((acc, sector) => acc + sector.projectCount, 0)}
              </div>
              <div className="text-sm text-muted-foreground">Total Projects</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-crypto-orange">
                {topMovers.length}
              </div>
              <div className="text-sm text-muted-foreground">Active Movers</div>
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="flex items-center space-x-4">
            <Select value={timeFilter} onValueChange={(value) => setTimeFilter(value as TimeFilter)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">24 Hours</SelectItem>
                <SelectItem value="7d">7 Days</SelectItem>
                <SelectItem value="30d">30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-4">
            <ExportDialog data={sortedSectors} type="sectors" />

            <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as ViewMode)}>
              <TabsList>
                <TabsTrigger value="heatmap">
                  <Activity className="h-4 w-4 mr-1" />
                  Heatmap
                </TabsTrigger>
                <TabsTrigger value="list">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  List
                </TabsTrigger>
                <TabsTrigger value="chart">
                  <PieChart className="h-4 w-4 mr-1" />
                  Chart
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Top Movers */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Top Movers (24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {topMovers.slice(0, 3).map((sector) => (
                <div key={sector.id} className="flex items-center space-x-3 p-3 rounded-lg bg-muted/20">
                  <div className={cn("p-2 rounded", `bg-${sector.color}/20`)}>
                    <Activity className={cn("h-4 w-4", `text-${sector.color}`)} />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm">{sector.name}</div>
                    <div className="text-xs text-muted-foreground">{formatHeatScore(sector.heatScore)}</div>
                  </div>
                  <Badge 
                    variant={sector.change24h >= 0 ? "default" : "destructive"}
                    className={sector.change24h >= 0 ? "bg-crypto-green text-white" : ""}
                  >
                    {sector.change24h >= 0 ? "+" : ""}{sector.change24h}%
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        {viewMode === 'heatmap' && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {sortedSectors.map((sector) => (
              <SectorHeatmapCard key={sector.id} sector={sector} />
            ))}
          </div>
        )}

        {viewMode === 'list' && (
          <div className="space-y-4">
            {sortedSectors.map((sector) => (
              <SectorListItem key={sector.id} sector={sector} />
            ))}
          </div>
        )}

        {viewMode === 'chart' && (
          <Card>
            <CardContent className="p-8">
              <div className="h-96 flex items-center justify-center bg-muted/20 rounded-lg">
                <div className="text-center">
                  <PieChart className="h-16 w-16 text-crypto-green mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground">Interactive charts coming soon</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Advanced data visualization and sector comparison tools
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Sector Detail Modal/Panel */}
        {selectedSector && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-3">
                    <div className={cn("p-2 rounded-lg", `bg-${selectedSector.color}/20`)}>
                      <Activity className={cn("h-6 w-6", `text-${selectedSector.color}`)} />
                    </div>
                    <span>{selectedSector.name} Sector</span>
                  </CardTitle>
                  <Button variant="ghost" onClick={() => setSelectedSector(null)}>
                    ×
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Sector Stats */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-crypto-green">
                      {formatHeatScore(selectedSector.heatScore)}
                    </div>
                    <div className="text-sm text-muted-foreground">Heat Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-foreground">
                      {selectedSector.projectCount}
                    </div>
                    <div className="text-sm text-muted-foreground">Projects</div>
                  </div>
                  <div className="text-center">
                    <div className={cn(
                      "text-2xl font-bold",
                      selectedSector.change24h >= 0 ? "text-crypto-green" : "text-crypto-red"
                    )}>
                      {selectedSector.change24h >= 0 ? "+" : ""}{selectedSector.change24h}%
                    </div>
                    <div className="text-sm text-muted-foreground">24h Change</div>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <h4 className="font-semibold mb-2">About {selectedSector.name}</h4>
                  <p className="text-muted-foreground">{selectedSector.description}</p>
                </div>

                {/* Top Projects */}
                <div>
                  <h4 className="font-semibold mb-3">Top Projects in {selectedSector.name}</h4>
                  <div className="space-y-2">
                    {getProjectsByCategory(selectedSector.name).slice(0, 5).map((project) => (
                      <div key={project.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                        <div className="flex items-center space-x-3">
                          <img
                            src={project.logo}
                            alt={project.name}
                            className="w-8 h-8 rounded-full"
                          />
                          <div>
                            <div className="font-medium text-sm">{project.name}</div>
                            <div className="text-xs text-muted-foreground">{project.intro}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="text-sm text-crypto-green font-semibold">
                            {formatHeatScore(project.heatScore)}
                          </span>
                          <Link to={`/project/${project.id}`} onClick={() => setSelectedSector(null)}>
                            <Button size="sm" variant="outline">View</Button>
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button className="flex-1" onClick={() => setSelectedSector(null)}>
                    Close
                  </Button>
                  <Link to="/directory" className="flex-1" onClick={() => setSelectedSector(null)}>
                    <Button variant="outline" className="w-full">
                      View All Projects
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Legend */}
        <div className="mt-8 flex items-center justify-center space-x-6 text-sm text-muted-foreground">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-heat-low border border-border" />
            <span>Low Activity</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-heat-medium border border-border" />
            <span>Medium Activity</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-heat-high border border-border" />
            <span>High Activity</span>
          </div>
        </div>
      </div>
    </div>
  );
}
