import { useState, useMemo, useEffect } from "react";
import { Search, Filter, SortAsc, SortDesc, Grid, List, ExternalLink, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  mockProjects,
  getAllCategories,
  getAllChains,
  formatHeatScore,
  formatPriceChange,
  type Project
} from "@/data/mockData";
import { ExportDialog } from "@/components/ExportDialog";
import { Link, useSearchParams } from "react-router-dom";

type SortOption = 'heat' | 'name' | 'marketCap' | 'volume' | 'change' | 'newest';
type ViewMode = 'grid' | 'list';

export default function ProjectDirectory() {
  const [searchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedChain, setSelectedChain] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [sortBy, setSortBy] = useState<SortOption>('heat');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  const categories = getAllCategories();
  const chains = getAllChains();

  // Handle URL search parameters
  useEffect(() => {
    const searchParam = searchParams.get('search');
    if (searchParam) {
      setSearchQuery(decodeURIComponent(searchParam));
    }
  }, [searchParams]);

  const filteredAndSortedProjects = useMemo(() => {
    let filtered = mockProjects.filter(project => {
      const matchesSearch = searchQuery === "" || 
        project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.intro.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === "all" || 
        project.categories.some(cat => cat === selectedCategory);
      
      const matchesChain = selectedChain === "all" || 
        project.chains.some(chain => chain === selectedChain);
      
      const matchesStatus = selectedStatus === "all" || project.status === selectedStatus;

      return matchesSearch && matchesCategory && matchesChain && matchesStatus;
    });

    // Sort projects
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'heat':
          comparison = a.heatScore - b.heatScore;
          break;
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'marketCap':
          const aMarketCap = parseFloat(a.marketCap?.replace(/[$MB]/g, '') || '0');
          const bMarketCap = parseFloat(b.marketCap?.replace(/[$MB]/g, '') || '0');
          comparison = aMarketCap - bMarketCap;
          break;
        case 'volume':
          const aVolume = parseFloat(a.volume24h?.replace(/[$MB]/g, '') || '0');
          const bVolume = parseFloat(b.volume24h?.replace(/[$MB]/g, '') || '0');
          comparison = aVolume - bVolume;
          break;
        case 'change':
          comparison = (a.priceChange24h || 0) - (b.priceChange24h || 0);
          break;
        case 'newest':
          comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
          break;
      }
      
      return sortOrder === 'desc' ? -comparison : comparison;
    });

    return filtered;
  }, [searchQuery, selectedCategory, selectedChain, selectedStatus, sortBy, sortOrder]);



  const ProjectCard = ({ project }: { project: Project }) => (
    <Card className="group hover:shadow-lg transition-all duration-300 border-border bg-card hover:border-crypto-green/30">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img
              src={project.logo}
              alt={project.name}
              className="w-12 h-12 rounded-full object-cover border-2 border-border"
            />
            <div>
              <Link to={`/project/${project.id}`}>
                <h3 className="font-semibold text-foreground group-hover:text-crypto-green transition-colors cursor-pointer">
                  {project.name}
                </h3>
              </Link>
              <div className="flex items-center space-x-1 mt-1">
                <TrendingUp className="h-3 w-3 text-crypto-green" />
                <span className="text-sm font-bold text-crypto-green">
                  {formatHeatScore(project.heatScore)}
                </span>
              </div>
            </div>
          </div>
          <Badge 
            variant={
              project.status === 'trending' ? 'default' : 
              project.status === 'new' ? 'secondary' : 'outline'
            }
            className={
              project.status === 'trending' ? 'bg-crypto-orange text-white' :
              project.status === 'new' ? 'bg-crypto-green text-white' : ''
            }
          >
            {project.status}
          </Badge>
        </div>

        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {project.intro}
        </p>

        <div className="flex flex-wrap gap-1 mb-4">
          {project.categories.slice(0, 3).map((category) => (
            <Badge key={category} variant="secondary" className="text-xs">
              {category}
            </Badge>
          ))}
        </div>

        <div className="flex flex-wrap gap-1 mb-4">
          {project.chains.map((chain) => (
            <Badge key={chain} variant="outline" className="text-xs">
              {chain}
            </Badge>
          ))}
        </div>

        {project.marketCap && (
          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-4">
            <div>Market Cap: <span className="text-foreground font-semibold">{project.marketCap}</span></div>
            <div>24h Vol: <span className="text-foreground font-semibold">{project.volume24h}</span></div>
          </div>
        )}

        {project.priceChange24h !== undefined && (
          <div className="text-xs mb-4">
            24h Change: <span className={formatPriceChange(project.priceChange24h).color}>
              {formatPriceChange(project.priceChange24h).value}
            </span>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex space-x-1">
            {project.twitterUrl && (
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-crypto-blue/10 hover:text-crypto-blue" asChild>
                <a href={project.twitterUrl} target="_blank" rel="noopener noreferrer">
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </a>
              </Button>
            )}
            {project.telegramUrl && (
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-crypto-blue/10 hover:text-crypto-blue" asChild>
                <a href={project.telegramUrl} target="_blank" rel="noopener noreferrer">
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.568 8.16l-1.61 7.548c-.121.546-.44.68-.892.424l-2.463-1.818-1.19 1.146c-.131.131-.243.243-.499.243l.178-2.516L15.672 9.6c.131-.117-.029-.183-.203-.066l-3.47 2.185-2.107-.658c-.457-.142-.466-.457.096-.676l8.252-3.181c.381-.142.714.088.59.676z" />
                  </svg>
                </a>
              </Button>
            )}
            {project.websiteUrl && (
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-crypto-green/10 hover:text-crypto-green" asChild>
                <a href={project.websiteUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
            )}
          </div>
          <Link to={`/project/${project.id}`}>
            <Button size="sm" variant="outline" className="hover:bg-crypto-green hover:text-white">
              View Details
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );

  const ProjectListItem = ({ project }: { project: Project }) => (
    <Card className="hover:shadow-md transition-all duration-300 border-border bg-card">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1">
            <img
              src={project.logo}
              alt={project.name}
              className="w-10 h-10 rounded-full object-cover border border-border"
            />
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <Link to={`/project/${project.id}`}>
                  <h3 className="font-semibold text-foreground hover:text-crypto-green transition-colors cursor-pointer">
                    {project.name}
                  </h3>
                </Link>
                <Badge 
                  variant={project.status === 'trending' ? 'default' : 'outline'}
                  className={project.status === 'trending' ? 'bg-crypto-orange text-white' : ''}
                >
                  {project.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground truncate">{project.intro}</p>
              <div className="flex items-center space-x-2 mt-1">
                {project.categories.slice(0, 2).map((category) => (
                  <Badge key={category} variant="secondary" className="text-xs">
                    {category}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div className="text-center">
              <div className="text-crypto-green font-semibold">{formatHeatScore(project.heatScore)}</div>
              <div className="text-xs text-muted-foreground">Heat</div>
            </div>
            
            {project.marketCap && (
              <div className="text-center">
                <div className="font-semibold">{project.marketCap}</div>
                <div className="text-xs text-muted-foreground">Market Cap</div>
              </div>
            )}
            
            {project.priceChange24h !== undefined && (
              <div className="text-center">
                <div className={formatPriceChange(project.priceChange24h).color}>
                  {formatPriceChange(project.priceChange24h).value}
                </div>
                <div className="text-xs text-muted-foreground">24h</div>
              </div>
            )}

            <div className="flex space-x-1">
              {project.websiteUrl && (
                <Button size="sm" variant="ghost" className="h-8 w-8 p-0" asChild>
                  <a href={project.websiteUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              )}
              <Link to={`/project/${project.id}`}>
                <Button size="sm" variant="outline">Details</Button>
              </Link>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">Project Directory</h1>
          <p className="text-muted-foreground">
            Explore {mockProjects.length} Web3 projects across multiple chains and sectors
          </p>
        </div>

        {/* Filters and Controls */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search projects, categories, or chains..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-full"
            />
          </div>

          {/* Filter Row */}
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedChain} onValueChange={setSelectedChain}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Chain" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Chains</SelectItem>
                  {chains.map(chain => (
                    <SelectItem key={chain} value={chain}>{chain}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="trending">Trending</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="rising">Rising</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="heat">Heat Score</SelectItem>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="marketCap">Market Cap</SelectItem>
                  <SelectItem value="volume">Volume</SelectItem>
                  <SelectItem value="change">24h Change</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              >
                {sortOrder === 'desc' ? <SortDesc className="h-4 w-4" /> : <SortAsc className="h-4 w-4" />}
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              <ExportDialog data={filteredAndSortedProjects} type="projects" />
              
              <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as ViewMode)}>
                <TabsList>
                  <TabsTrigger value="grid">
                    <Grid className="h-4 w-4" />
                  </TabsTrigger>
                  <TabsTrigger value="list">
                    <List className="h-4 w-4" />
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4 text-sm text-muted-foreground">
          Showing {filteredAndSortedProjects.length} of {mockProjects.length} projects
        </div>

        {/* Projects Grid/List */}
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAndSortedProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredAndSortedProjects.map((project) => (
              <ProjectListItem key={project.id} project={project} />
            ))}
          </div>
        )}

        {filteredAndSortedProjects.length === 0 && (
          <div className="text-center py-16">
            <div className="text-muted-foreground text-lg mb-2">No projects found</div>
            <p className="text-sm text-muted-foreground">
              Try adjusting your search criteria or filters
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
