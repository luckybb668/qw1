import { useParams, Link } from "react-router-dom";
import { ArrowLeft, ExternalLink, TrendingUp, Users, Globe, MessageCircle, Share2, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockProjects, formatHeatScore, formatPriceChange, type Project } from "@/data/mockData";

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const project = mockProjects.find(p => p.id === id);

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">Project Not Found</h2>
          <p className="text-muted-foreground mb-6">The project you're looking for doesn't exist.</p>
          <Link to="/directory">
            <Button>Back to Directory</Button>
          </Link>
        </div>
      </div>
    );
  }

  const mockHeatTrend = [
    { date: '2024-01-01', heat: project.heatScore * 0.6 },
    { date: '2024-01-02', heat: project.heatScore * 0.7 },
    { date: '2024-01-03', heat: project.heatScore * 0.8 },
    { date: '2024-01-04', heat: project.heatScore * 0.9 },
    { date: '2024-01-05', heat: project.heatScore },
  ];

  const relatedProjects = mockProjects
    .filter(p => p.id !== project.id && p.categories.some(cat => project.categories.includes(cat)))
    .slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Navigation */}
        <div className="mb-6">
          <Link to="/directory" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Directory</span>
          </Link>
        </div>

        {/* Project Header */}
        <div className="mb-8">
          <Card className="border-border bg-card">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between space-y-6 lg:space-y-0">
                <div className="flex items-center space-x-6">
                  <img
                    src={project.logo}
                    alt={project.name}
                    className="w-20 h-20 rounded-2xl object-cover border-2 border-border"
                  />
                  <div>
                    <div className="flex items-center space-x-3 mb-2">
                      <h1 className="text-3xl font-bold text-foreground">{project.name}</h1>
                      <Badge 
                        variant={
                          project.status === 'trending' ? 'default' : 
                          project.status === 'new' ? 'secondary' : 'outline'
                        }
                        className={
                          project.status === 'trending' ? 'bg-crypto-orange text-white' :
                          project.status === 'new' ? 'bg-crypto-green text-white' : ''
                        }
                      >
                        {project.status}
                      </Badge>
                    </div>
                    <p className="text-lg text-muted-foreground mb-4">{project.intro}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.categories.map((category) => (
                        <Badge key={category} variant="secondary">
                          {category}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col lg:items-end space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-crypto-green">{formatHeatScore(project.heatScore)}</div>
                      <div className="text-sm text-muted-foreground">Heat Score</div>
                    </div>
                    {project.priceChange24h !== undefined && (
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${formatPriceChange(project.priceChange24h).color}`}>
                          {formatPriceChange(project.priceChange24h).value}
                        </div>
                        <div className="text-sm text-muted-foreground">24h Change</div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Star className="h-4 w-4 mr-1" />
                      Watchlist
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {project.marketCap && (
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-foreground">{project.marketCap}</div>
                <div className="text-sm text-muted-foreground">Market Cap</div>
              </CardContent>
            </Card>
          )}
          
          {project.volume24h && (
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-foreground">{project.volume24h}</div>
                <div className="text-sm text-muted-foreground">24h Volume</div>
              </CardContent>
            </Card>
          )}
          
          {project.followers?.twitter && (
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-foreground">{project.followers.twitter.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Twitter Followers</div>
              </CardContent>
            </Card>
          )}
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-foreground">{project.chains.length}</div>
              <div className="text-sm text-muted-foreground">Supported Chains</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="community">Community</TabsTrigger>
            <TabsTrigger value="related">Related</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Description */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>About {project.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      {project.description}
                    </p>
                    
                    <Separator className="my-6" />
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold text-foreground mb-2">Categories</h4>
                        <div className="flex flex-wrap gap-2">
                          {project.categories.map((category) => (
                            <Badge key={category} variant="outline">
                              {category}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-foreground mb-2">Supported Chains</h4>
                        <div className="flex flex-wrap gap-2">
                          {project.chains.map((chain) => (
                            <Badge key={chain} variant="outline">
                              {chain}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      {project.tags && (
                        <div>
                          <h4 className="font-semibold text-foreground mb-2">Tags</h4>
                          <div className="flex flex-wrap gap-2">
                            {project.tags.map((tag) => (
                              <Badge key={tag} variant="secondary">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Links & Info */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Links</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {project.websiteUrl && (
                      <Button variant="outline" className="w-full justify-start" asChild>
                        <a href={project.websiteUrl} target="_blank" rel="noopener noreferrer">
                          <Globe className="h-4 w-4 mr-2" />
                          Official Website
                        </a>
                      </Button>
                    )}
                    
                    {project.twitterUrl && (
                      <Button variant="outline" className="w-full justify-start" asChild>
                        <a href={project.twitterUrl} target="_blank" rel="noopener noreferrer">
                          <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                          </svg>
                          Twitter
                        </a>
                      </Button>
                    )}
                    
                    {project.telegramUrl && (
                      <Button variant="outline" className="w-full justify-start" asChild>
                        <a href={project.telegramUrl} target="_blank" rel="noopener noreferrer">
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Telegram
                        </a>
                      </Button>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Project Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Added:</span>
                      <span className="font-medium">{new Date(project.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Data Source:</span>
                      <span className="font-medium">{project.sourcePlatform}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <Badge variant="outline" className="capitalize">{project.status}</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Heat Score Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-muted/20 rounded-lg">
                    <div className="text-center">
                      <TrendingUp className="h-12 w-12 text-crypto-green mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">Heat trend chart would be displayed here</p>
                      <p className="text-xs text-muted-foreground mt-1">Current: {formatHeatScore(project.heatScore)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Social Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {project.followers?.twitter && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Twitter Followers</span>
                        <span className="font-semibold">{project.followers.twitter.toLocaleString()}</span>
                      </div>
                    )}
                    {project.followers?.telegram && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Telegram Members</span>
                        <span className="font-semibold">{project.followers.telegram.toLocaleString()}</span>
                      </div>
                    )}
                    {project.followers?.discord && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Discord Members</span>
                        <span className="font-semibold">{project.followers.discord.toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="community" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Community Channels</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {project.twitterUrl && (
                    <Card className="text-center p-4">
                      <div className="mb-2">
                        <svg className="h-8 w-8 mx-auto text-crypto-blue" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                        </svg>
                      </div>
                      <h4 className="font-semibold mb-1">Twitter</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {project.followers?.twitter ? `${project.followers.twitter.toLocaleString()} followers` : 'Follow for updates'}
                      </p>
                      <Button variant="outline" size="sm" asChild>
                        <a href={project.twitterUrl} target="_blank" rel="noopener noreferrer">
                          Follow
                        </a>
                      </Button>
                    </Card>
                  )}

                  {project.telegramUrl && (
                    <Card className="text-center p-4">
                      <div className="mb-2">
                        <MessageCircle className="h-8 w-8 mx-auto text-crypto-blue" />
                      </div>
                      <h4 className="font-semibold mb-1">Telegram</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {project.followers?.telegram ? `${project.followers.telegram.toLocaleString()} members` : 'Join the community'}
                      </p>
                      <Button variant="outline" size="sm" asChild>
                        <a href={project.telegramUrl} target="_blank" rel="noopener noreferrer">
                          Join
                        </a>
                      </Button>
                    </Card>
                  )}

                  {project.discordUrl && (
                    <Card className="text-center p-4">
                      <div className="mb-2">
                        <Users className="h-8 w-8 mx-auto text-crypto-purple" />
                      </div>
                      <h4 className="font-semibold mb-1">Discord</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {project.followers?.discord ? `${project.followers.discord.toLocaleString()} members` : 'Join discussions'}
                      </p>
                      <Button variant="outline" size="sm" asChild>
                        <a href={project.discordUrl} target="_blank" rel="noopener noreferrer">
                          Join
                        </a>
                      </Button>
                    </Card>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="related" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Related Projects</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {relatedProjects.map((relatedProject) => (
                    <Card key={relatedProject.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3 mb-3">
                          <img
                            src={relatedProject.logo}
                            alt={relatedProject.name}
                            className="w-10 h-10 rounded-full object-cover border border-border"
                          />
                          <div>
                            <h4 className="font-semibold text-sm">{relatedProject.name}</h4>
                            <p className="text-xs text-muted-foreground">{relatedProject.intro}</p>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-crypto-green font-semibold">
                            {formatHeatScore(relatedProject.heatScore)}
                          </span>
                          <Link to={`/project/${relatedProject.id}`}>
                            <Button size="sm" variant="outline">View</Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
