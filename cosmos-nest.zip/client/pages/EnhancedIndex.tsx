import { useState, useEffect } from "react";
import { 
  TrendingUp, Globe, Activity, Users, BarChart3, Loader2, Star, 
  Zap, ArrowUpRight, Eye, Filter, Search, Bell, Sparkles, Crown 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { mockProjects, mockSectors, formatHeatScore } from "@/data/mockData";
import { useLiveStatistics, useTrendingProjects, useSectorHeatmap } from "@/hooks/useApi";
import { useTheme } from "@/contexts/ThemeContext";
import { Link } from "react-router-dom";

export default function EnhancedIndex() {
  const { effectiveTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTimeframe, setSelectedTimeframe] = useState('24h');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // API数据
  const { data: statsData, loading: statsLoading } = useLiveStatistics();
  const { data: trendingData, loading: trendingLoading } = useTrendingProjects({ limit: 8 });
  const { data: sectorsData, loading: sectorsLoading } = useSectorHeatmap();

  const liveStats = statsData || {
    total_projects: 605,
    active_sectors: 77,
    today_trending: 87,
    total_users: 601
  };

  const hotSectors = sectorsData?.sectors
    ? sectorsData.sectors.slice(0, 6)
    : [...mockSectors].sort((a, b) => b.heatScore - a.heatScore).slice(0, 6);

  const trendingProjects = trendingData?.projects
    ? trendingData.projects
    : [...mockProjects].sort((a, b) => b.heatScore - a.heatScore).slice(0, 8);

  // 背景动画点
  const BackgroundAnimation = () => (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {[...Array(50)].map((_, i) => (
        <div
          key={i}
          className={`absolute rounded-full opacity-20 animate-pulse ${
            effectiveTheme === 'dark' ? 'bg-gradient-to-r from-cyan-400 to-purple-500' : 'bg-gradient-to-r from-blue-400 to-indigo-500'
          }`}
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: `${Math.random() * 4 + 1}px`,
            height: `${Math.random() * 4 + 1}px`,
            animationDelay: `${Math.random() * 2}s`,
            animationDuration: `${Math.random() * 3 + 2}s`
          }}
        />
      ))}
    </div>
  );

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      effectiveTheme === 'dark' 
        ? 'bg-gradient-to-br from-gray-900 via-purple-900/20 to-cyan-900/20' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50/50 to-purple-50/30'
    }`}>
      <BackgroundAnimation />
      
      {/* Hero Section with Glassmorphism */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          {/* 主标题区域 */}
          <div className="text-center mb-16">
            {/* 装饰性徽章 */}
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 backdrop-blur-sm border border-cyan-500/20 rounded-full px-4 py-2 mb-6">
              <Crown className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-medium text-cyan-400">全球领先的Web3数据平台</span>
              <Sparkles className="w-4 h-4 text-purple-400" />
            </div>

            {/* 主标题 */}
            <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent leading-tight">
              HotWeb3.io
            </h1>
            
            {/* 副标题 */}
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              实时追踪Web3项目热度，智能分析行业趋势
              <br />
              <span className="text-lg opacity-80">AI-Powered Web3 Analytics & Trend Intelligence</span>
            </p>

            {/* 搜索栏 */}
            <div className="max-w-md mx-auto mb-12">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="搜索项目、板块或代币..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-4 py-4 text-lg bg-background/50 backdrop-blur-sm border-2 border-cyan-500/20 focus:border-cyan-500/50 rounded-xl"
                />
                <Button 
                  size="sm" 
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                >
                  <Zap className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* 统计数据卡片 - Glassmorphism 设计 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto mb-20">
            {[
              { 
                value: liveStats.total_projects, 
                label: "项目总数", 
                icon: Globe, 
                color: "from-cyan-500 to-blue-500",
                change: "+12%"
              },
              { 
                value: liveStats.active_sectors, 
                label: "活跃板块", 
                icon: Activity, 
                color: "from-purple-500 to-pink-500",
                change: "+8%"
              },
              { 
                value: liveStats.today_trending, 
                label: "今日热门", 
                icon: TrendingUp, 
                color: "from-green-500 to-emerald-500",
                change: "+24%"
              },
              { 
                value: liveStats.total_users, 
                label: "活跃用户", 
                icon: Users, 
                color: "from-orange-500 to-red-500",
                change: "+15%"
              }
            ].map((stat, index) => (
              <Card key={index} className="bg-background/30 backdrop-blur-md border border-white/10 hover:bg-background/40 transition-all duration-300 group hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${stat.color} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-3xl font-bold mb-2">
                    {statsLoading ? (
                      <Loader2 className="w-8 h-8 animate-spin mx-auto" />
                    ) : (
                      <span className="bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent">
                        {stat.value}
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground mb-1">{stat.label}</div>
                  <div className="text-xs text-green-500 font-medium">{stat.change}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Hot Sectors - 六边形网格设计 */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-center animate-pulse">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-4xl font-bold bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent">
                🔥 热门板块实时榜
              </h2>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              基于社交媒体热度、交易量、项目活跃度的综合排名
            </p>
          </div>

          {/* 六边形网格布局 */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 max-w-6xl mx-auto mb-12">
            {hotSectors.map((sector, index) => {
              const sectorColors = [
                'from-cyan-500 to-blue-600',
                'from-purple-500 to-pink-600', 
                'from-green-500 to-emerald-600',
                'from-orange-500 to-red-600',
                'from-indigo-500 to-purple-600',
                'from-teal-500 to-cyan-600'
              ];
              
              return (
                <Card 
                  key={sector.id}
                  className="relative group cursor-pointer bg-background/20 backdrop-blur-md border border-white/10 hover:border-cyan-500/50 transition-all duration-500 hover:scale-110 hover:rotate-2"
                >
                  <CardContent className="p-6 text-center">
                    {/* 排名徽章 */}
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {index + 1}
                    </div>
                    
                    {/* 图标 */}
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${sectorColors[index]} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <span className="text-2xl">
                        {sector.name === 'AI' && '🤖'}
                        {sector.name === 'DeFi' && '💰'}
                        {sector.name === 'NFT' && '🎨'}
                        {sector.name === 'GameFi' && '🎮'}
                        {sector.name === 'SocialFi' && '👥'}
                        {sector.name === 'Memecoin' && '🐕'}
                        {!['AI', 'DeFi', 'NFT', 'GameFi', 'SocialFi', 'Memecoin'].includes(sector.name) && '🔥'}
                      </span>
                    </div>
                    
                    {/* 板块信息 */}
                    <h3 className="font-bold text-lg mb-2 group-hover:text-cyan-400 transition-colors">
                      {sector.name}
                    </h3>
                    
                    <div className="text-2xl font-bold text-cyan-400 mb-1">
                      {formatHeatScore(sector.heat_score || sector.heatScore)}
                    </div>
                    
                    <div className="text-xs text-muted-foreground mb-2">
                      {sector.project_count || sector.projectCount} 项目
                    </div>
                    
                    {/* 变化指示器 */}
                    <div className={`text-xs font-medium ${
                      (sector.change24h || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {(sector.change24h || 0) >= 0 ? '↗' : '↘'} {Math.abs(sector.change24h || 0)}%
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* 查看更多按钮 */}
          <div className="text-center">
            <Link to="/sectors">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white px-8 py-4 rounded-xl font-semibold shadow-2xl hover:shadow-cyan-500/25 transition-all duration-300"
              >
                <BarChart3 className="mr-2 w-5 h-5" />
                查看完整热度图
                <ArrowUpRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trending Projects - 卡片网格 */}
      <section className="py-20 bg-background/20 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                💎 趋势项目
              </h2>
              <p className="text-muted-foreground text-lg">基于社交热度和资金流向的智能排序</p>
            </div>
            
            {/* 时间筛选器 */}
            <div className="flex items-center space-x-2 bg-background/50 backdrop-blur-sm rounded-xl p-1">
              {['24h', '7d', '30d'].map((timeframe) => (
                <button
                  key={timeframe}
                  onClick={() => setSelectedTimeframe(timeframe)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    selectedTimeframe === timeframe
                      ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white shadow-lg'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {timeframe}
                </button>
              ))}
            </div>
          </div>

          {/* 项目网格 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {trendingProjects.slice(0, 8).map((project, index) => (
              <Card 
                key={project.id}
                className="group bg-background/30 backdrop-blur-md border border-white/10 hover:border-cyan-500/50 transition-all duration-300 hover:scale-105 hover:-translate-y-1"
              >
                <CardContent className="p-6">
                  {/* 头部信息 */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <img
                          src={project.logo_url || project.logo}
                          alt={project.name}
                          className="w-12 h-12 rounded-xl object-cover border-2 border-cyan-500/20"
                        />
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
                          {index + 1}
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg group-hover:text-cyan-400 transition-colors">
                          {project.name}
                        </h3>
                        <div className="flex items-center space-x-1">
                          <TrendingUp className="w-3 h-3 text-cyan-400" />
                          <span className="text-sm font-medium text-cyan-400">
                            {formatHeatScore(project.heat_score || project.heatScore)}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    {/* 收藏按钮 */}
                    <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <Star className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* 项目描述 */}
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {project.description || project.intro}
                  </p>

                  {/* 标签 */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {(project.categories || []).slice(0, 2).map((category: string) => (
                      <Badge 
                        key={category} 
                        variant="secondary" 
                        className="text-xs bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                      >
                        {category}
                      </Badge>
                    ))}
                  </div>

                  {/* 底部信息 */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Eye className="w-3 h-3" />
                        <span>2.4k</span>
                      </div>
                      {(project.market_data?.price_change_24h || project.priceChange24h) !== undefined && (
                        <div className={`flex items-center space-x-1 ${
                          (project.market_data?.price_change_24h || project.priceChange24h) >= 0 
                            ? 'text-green-400' 
                            : 'text-red-400'
                        }`}>
                          <TrendingUp className="w-3 h-3" />
                          <span>
                            {(project.market_data?.price_change_24h || project.priceChange24h) >= 0 ? '+' : ''}
                            {(project.market_data?.price_change_24h || project.priceChange24h).toFixed(1)}%
                          </span>
                        </div>
                      )}
                    </div>
                    
                    <Link to={`/project/${project.id}`}>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        className="opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-cyan-500/10 hover:text-cyan-400"
                      >
                        查看 <ArrowUpRight className="w-3 h-3 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* 查看更多 */}
          <div className="text-center">
            <Link to="/directory">
              <Button 
                variant="outline" 
                size="lg"
                className="border-cyan-500/20 text-cyan-400 hover:bg-cyan-500/10 hover:border-cyan-500/50 px-8 py-4 rounded-xl"
              >
                查看所有项目 ({liveStats.total_projects}+)
                <ArrowUpRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 backdrop-blur-sm"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              每天一分钟，掌握Web3脉搏
            </h2>
            <p className="text-xl text-muted-foreground mb-12 leading-relaxed">
              智能数据分析 · 实时趋势追踪 · 专业投资洞察
              <br />
              <span className="text-lg opacity-80">让数据驱动您的Web3投资决策</span>
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white px-8 py-4 rounded-xl font-semibold shadow-2xl hover:shadow-cyan-500/25 transition-all duration-300"
              >
                <Bell className="mr-2 w-5 h-5" />
                订阅热度提醒
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-cyan-500/20 text-cyan-400 hover:bg-cyan-500/10 hover:border-cyan-500/50 px-8 py-4 rounded-xl"
              >
                <Activity className="mr-2 w-5 h-5" />
                API 接入
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
