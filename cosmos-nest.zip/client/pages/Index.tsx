import { useState, useEffect } from "react";
import { TrendingUp, Globe, Activity, Users, BarChart3, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { mockProjects, mockSectors, formatHeatScore } from "@/data/mockData";
import { useLiveStatistics, useTrendingProjects, useSectorHeatmap } from "@/hooks/useApi";
import { Link } from "react-router-dom";

// 实时统计数据接口
interface LiveStats {
  totalProjects: number;
  activeSectors: number;
  todayTrending: number;
  totalUsers: number;
}

export default function Index() {
  // 使用API Hooks获取实时数据
  const { data: statsData, loading: statsLoading } = useLiveStatistics();
  const { data: trendingData, loading: trendingLoading } = useTrendingProjects({ limit: 6 });
  const { data: sectorsData, loading: sectorsLoading } = useSectorHeatmap();

  // 使用API数据或回退到模拟数据
  const liveStats = statsData || {
    total_projects: 605,
    active_sectors: 77,
    today_trending: 87,
    total_users: 601
  };

  // 获取热门板块（圆形显示）
  const hotSectors = sectorsData?.sectors
    ? sectorsData.sectors.slice(0, 4)
    : [...mockSectors].sort((a, b) => b.heatScore - a.heatScore).slice(0, 4);

  // 获取趋势项目
  const trendingProjects = trendingData?.projects
    ? trendingData.projects
    : [...mockProjects].sort((a, b) => b.heatScore - a.heatScore).slice(0, 6);

  // 获取板块颜色和大小
  const getSectorSize = (index: number) => {
    const sizes = [
      { width: 200, height: 200 }, // 最大
      { width: 160, height: 160 }, // 第二大
      { width: 140, height: 140 }, // 第三大
      { width: 120, height: 120 }  // 最小
    ];
    return sizes[index] || sizes[3];
  };

  const getSectorColor = (sector: any, index: number) => {
    const colors = [
      'from-green-400 to-green-600',    // SocialFi - 绿色
      'from-orange-400 to-orange-600',  // Memecoin - 橙色
      'from-purple-400 to-purple-600',  // AI - 紫色
      'from-red-400 to-red-600'        // DeFi - 红色
    ];
    return colors[index] || colors[3];
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* 主标题区域 */}
      <section className="pt-20 pb-16 text-center">
        <div className="container mx-auto px-4">
          {/* HotWeb3.io 大标题 */}
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            HotWeb3.io
          </h1>
          
          {/* 副标题 */}
          <p className="text-gray-400 text-lg mb-16 max-w-2xl mx-auto">
            Перспективы проекты Web3 кето, Roficomtensiek
          </p>

          {/* 统计数据区域 - 4列布局 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto mb-20">
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">
                {statsLoading ? (
                  <Loader2 className="h-10 w-10 animate-spin mx-auto" />
                ) : (
                  liveStats.total_projects
                )}
              </div>
              <div className="text-gray-400 text-sm">项目总数</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-400 mb-2">
                {statsLoading ? (
                  <Loader2 className="h-10 w-10 animate-spin mx-auto" />
                ) : (
                  liveStats.active_sectors
                )}
              </div>
              <div className="text-gray-400 text-sm">活跃板块</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">
                {statsLoading ? (
                  <Loader2 className="h-10 w-10 animate-spin mx-auto" />
                ) : (
                  liveStats.today_trending
                )}
              </div>
              <div className="text-gray-400 text-sm">今日热门</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">
                {statsLoading ? (
                  <Loader2 className="h-10 w-10 animate-spin mx-auto" />
                ) : (
                  liveStats.total_users
                )}
              </div>
              <div className="text-gray-400 text-sm">活跃用户</div>
            </div>
          </div>
        </div>
      </section>

      {/* Hot Sectors 圆形展示区域 */}
      <section className="py-16 bg-gray-800/50">
        <div className="container mx-auto px-4 text-center">
          {/* 火焰图标和标题 */}
          <div className="mb-4">
            <div className="inline-flex items-center space-x-3 mb-4">
              <span className="text-3xl">🔥</span>
              <h2 className="text-3xl font-bold text-white">Hot Sectors</h2>
            </div>
            <p className="text-gray-400 mb-12">
              Real-time sector heat rankings based on social media and trading volume
            </p>
          </div>

          {/* 圆形板块展示 */}
          <div className="flex items-center justify-center space-x-8 mb-16 flex-wrap gap-8">
            {hotSectors.map((sector, index) => {
              const size = getSectorSize(index);
              const colorClass = getSectorColor(sector, index);
              
              return (
                <div
                  key={sector.id}
                  className="relative group cursor-pointer"
                  style={{ width: size.width, height: size.height }}
                >
                  <div
                    className={`w-full h-full rounded-full bg-gradient-to-br ${colorClass} flex items-center justify-center text-white font-bold text-lg shadow-2xl transform transition-all duration-300 hover:scale-110 hover:shadow-3xl`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">
                        {sector.name === 'SocialFi' && '👥'}
                        {sector.name === 'Memecoin' && '🐕'}
                        {sector.name === 'AI' && '🤖'}
                        {sector.name === 'DeFi' && '💰'}
                      </div>
                      <div className="font-bold">{sector.name}</div>
                      <div className="text-sm opacity-90">
                        {formatHeatScore(sector.heat_score || sector.heatScore)}
                      </div>
                    </div>
                  </div>
                  
                  {/* 悬浮信息 */}
                  <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="bg-gray-700 px-3 py-1 rounded text-sm whitespace-nowrap">
                      {sector.project_count || sector.projectCount} projects
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* 查看更多按钮 */}
          <Link to="/sectors">
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 rounded-lg font-semibold">
              View Complete Heatmap
            </Button>
          </Link>
        </div>
      </section>

      {/* Trending Projects 区域 */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-white mb-2 italic">Trending Projects</h2>
            <p className="text-gray-400">
              Top projects ranked by social media heat and community engagement
            </p>
          </div>

          {/* 项目标签栏 */}
          <div className="flex space-x-1 mb-8 bg-gray-800 p-1 rounded-lg inline-flex">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium">
              All
            </button>
            <button className="px-4 py-2 text-gray-400 hover:text-white rounded-md text-sm font-medium">
              DeFi
            </button>
            <button className="px-4 py-2 text-gray-400 hover:text-white rounded-md text-sm font-medium">
              NFT
            </button>
            <button className="px-4 py-2 text-gray-400 hover:text-white rounded-md text-sm font-medium">
              Gaming
            </button>
            <button className="px-4 py-2 text-gray-400 hover:text-white rounded-md text-sm font-medium">
              AI
            </button>
          </div>

          {/* 项目列表 */}
          <div className="space-y-4">
            {trendingProjects.map((project, index) => (
              <div
                key={project.id}
                className="bg-gray-800/50 rounded-lg p-4 flex items-center justify-between hover:bg-gray-800 transition-colors duration-300 group"
              >
                <div className="flex items-center space-x-4">
                  {/* 项目Logo */}
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      src={project.logo_url || project.logo}
                      alt={project.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* 项目信息 */}
                  <div>
                    <h3 className="text-white font-semibold text-lg group-hover:text-blue-400 transition-colors">
                      {project.name}
                    </h3>
                    <p className="text-gray-400 text-sm">{project.description || project.intro}</p>
                  </div>
                </div>

                {/* 右侧信息 */}
                <div className="flex items-center space-x-6 text-right">
                  {/* 分类标签 */}
                  <div className="flex flex-wrap gap-1">
                    {(project.categories || []).slice(0, 2).map((category: string) => (
                      <Badge
                        key={category}
                        variant="secondary"
                        className="text-xs bg-gray-700 text-gray-300"
                      >
                        {category}
                      </Badge>
                    ))}
                  </div>

                  {/* 热度分数 */}
                  <div className="text-center">
                    <div className="text-green-400 font-bold text-lg">
                      {formatHeatScore(project.heat_score || project.heatScore)}
                    </div>
                    <div className="text-gray-500 text-xs">Heat Score</div>
                  </div>

                  {/* 24h变化 */}
                  {(project.market_data?.price_change_24h || project.priceChange24h) !== undefined && (
                    <div className="text-center">
                      <div className={`font-semibold ${(project.market_data?.price_change_24h || project.priceChange24h) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {(project.market_data?.price_change_24h || project.priceChange24h) >= 0 ? '+' : ''}{(project.market_data?.price_change_24h || project.priceChange24h).toFixed(1)}%
                      </div>
                      <div className="text-gray-500 text-xs">24h</div>
                    </div>
                  )}

                  {/* 查看详情按钮 */}
                  <Link to={`/project/${project.id}`}>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-gray-600 text-gray-300 hover:bg-blue-600 hover:text-white hover:border-blue-600"
                    >
                      Details
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {/* 查看更多项目 */}
          <div className="text-center mt-12">
            <Link to="/directory">
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 px-8 py-3"
              >
                View All Projects →
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 底部CTA区域 */}
      <section className="py-16 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            每天一分钟，掌握全球Web3热度趋势
          </h2>
          <p className="text-gray-400 text-lg mb-8">
            投资者、项目方、玩家都在用的行业温度计
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link to="/directory">
              <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-8 py-3 rounded-lg">
                <BarChart3 className="mr-2 h-5 w-5" />
                浏览所有项目
              </Button>
            </Link>
            <Link to="/sectors">
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 px-8 py-3"
              >
                <Activity className="mr-2 h-5 w-5" />
                查看行业热度图
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
