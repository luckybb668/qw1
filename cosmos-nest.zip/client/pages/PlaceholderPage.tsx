import { Construction, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface PlaceholderPageProps {
  title: string;
}

export default function PlaceholderPage({ title }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="border-border bg-card">
            <CardContent className="p-12">
              <div className="mb-6">
                <div className="h-16 w-16 rounded-full bg-gradient-to-br from-crypto-green to-crypto-blue flex items-center justify-center mx-auto">
                  <Construction className="h-8 w-8 text-white" />
                </div>
              </div>
              
              <h1 className="text-3xl font-bold text-foreground mb-4">
                {title} Coming Soon
              </h1>
              
              <p className="text-muted-foreground mb-8 text-lg">
                We're working hard to bring you the best {title.toLowerCase()} experience. 
                This section will be available soon with comprehensive features and data.
              </p>
              
              <div className="space-y-4">
                <Button 
                  className="bg-gradient-to-r from-crypto-green to-crypto-blue hover:from-crypto-green/90 hover:to-crypto-blue/90"
                  asChild
                >
                  <a href="/">
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Return to Homepage
                  </a>
                </Button>
                
                <p className="text-sm text-muted-foreground">
                  In the meantime, check out our trending projects and sector analysis on the homepage.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
