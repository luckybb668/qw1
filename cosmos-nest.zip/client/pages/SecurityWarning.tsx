import { Shield, AlertTriangle, RefreshCw, Home, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTheme } from "@/contexts/ThemeContext";
import { Link } from "react-router-dom";

export default function SecurityWarning() {
  const { effectiveTheme } = useTheme();

  const handleRefresh = () => {
    // 清除本地存储的可疑活动记录
    localStorage.removeItem('suspicious_activity_count');
    window.location.href = '/';
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 ${
      effectiveTheme === 'dark' 
        ? 'bg-gradient-to-br from-gray-900 via-red-900/20 to-orange-900/20' 
        : 'bg-gradient-to-br from-red-50 via-orange-50/50 to-yellow-50/30'
    }`}>
      <Card className="max-w-2xl w-full bg-background/80 backdrop-blur-md border-red-500/20">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-20 h-20 rounded-full bg-gradient-to-r from-red-500 to-orange-500 flex items-center justify-center mb-6">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-red-600 dark:text-red-400">
            🔒 安全防护已激活
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* 警告信息 */}
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-500/30 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-red-800 dark:text-red-300 mb-2">
                  检测到异常活动
                </h3>
                <p className="text-red-700 dark:text-red-400 text-sm">
                  我们的安全系统检测到您的访问行为可能存在异常。为了保护平台和用户数据安全，您的访问已被暂时限制。
                </p>
              </div>
            </div>
          </div>

          {/* 可能的原因 */}
          <div>
            <h4 className="font-semibold text-foreground mb-3">可能的原因包括：</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span>
                <span>频繁的API请求或异常操作模式</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span>
                <span>使用自动化工具或脚本访问</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span>
                <span>尝试访问受限制的功能或数据</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span>
                <span>网络连接异常或IP地址变更</span>
              </li>
            </ul>
          </div>

          {/* 解决方案 */}
          <div>
            <h4 className="font-semibold text-foreground mb-3">如何解决：</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
                <RefreshCw className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                <div>
                  <h5 className="font-medium text-foreground">等待并重试</h5>
                  <p className="text-sm text-muted-foreground">
                    请等待几分钟后刷新页面，大多数情况下限制会自动解除
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
                <Mail className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <h5 className="font-medium text-foreground">联系客服</h5>
                  <p className="text-sm text-muted-foreground">
                    如果问题持续存在，请发送邮件至 security@hotweb3.io 说明情况
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 安全提示 */}
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-500/30 rounded-lg p-4">
            <h4 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">
              💡 安全提示
            </h4>
            <ul className="text-sm text-blue-700 dark:text-blue-400 space-y-1">
              <li>• 请勿使用自动化工具频繁访问网站</li>
              <li>• 避免在短时间内进行大量操作</li>
              <li>• 使用最新版本的浏览器以获得最佳体验</li>
              <li>• 如需API访问，请申请官方API密钥</li>
            </ul>
          </div>

          {/* 操作按钮 */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button 
              onClick={handleRefresh}
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              重新尝试访问
            </Button>
            
            <Link to="/" className="flex-1">
              <Button variant="outline" className="w-full">
                <Home className="w-4 h-4 mr-2" />
                返回首页
              </Button>
            </Link>
          </div>

          {/* 联系信息 */}
          <div className="text-center pt-4 border-t border-border">
            <p className="text-sm text-muted-foreground">
              如有疑问，请联系客服邮箱：
              <a 
                href="mailto:security@hotweb3.io" 
                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-medium ml-1"
              >
                security@hotweb3.io
              </a>
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              我们致力于为所有用户提供安全可靠的服务体验
            </p>
          </div>
        </CardContent>
      </Card>

      {/* 背景装饰 */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-10 bg-red-500 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${Math.random() * 6 + 2}px`,
              height: `${Math.random() * 6 + 2}px`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${Math.random() * 2 + 1}s`
            }}
          />
        ))}
      </div>
    </div>
  );
}
