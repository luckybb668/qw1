import { mockProjects, mockSectors, type Project, type Sector } from "@/data/mockData";

export interface ExportOptions {
  format: 'csv' | 'json' | 'txt';
  includeAllFields?: boolean;
  dateRange?: {
    start: string;
    end: string;
  };
}

export const exportProjects = (projects: Project[], options: ExportOptions) => {
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `hotweb3_projects_${timestamp}`;

  switch (options.format) {
    case 'csv':
      exportAsCSV(projects, filename);
      break;
    case 'json':
      exportAsJSON(projects, filename);
      break;
    case 'txt':
      exportAsTXT(projects, filename);
      break;
  }
};

export const exportSectors = (sectors: Sector[], options: ExportOptions) => {
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `hotweb3_sectors_${timestamp}`;

  switch (options.format) {
    case 'csv':
      exportSectorsAsCSV(sectors, filename);
      break;
    case 'json':
      exportAsJSON(sectors, filename);
      break;
    case 'txt':
      exportSectorsAsTXT(sectors, filename);
      break;
  }
};

const exportAsCSV = (projects: Project[], filename: string) => {
  const headers = [
    'Name',
    'Categories',
    'Chains',
    'Heat Score',
    'Market Cap',
    '24h Volume',
    '24h Change',
    'Status',
    'Website',
    'Twitter',
    'Telegram',
    'Created Date'
  ];

  const csvContent = [
    headers.join(','),
    ...projects.map(project => [
      `"${project.name}"`,
      `"${project.categories.join(', ')}"`,
      `"${project.chains.join(', ')}"`,
      project.heatScore,
      `"${project.marketCap || ''}"`,
      `"${project.volume24h || ''}"`,
      project.priceChange24h || '',
      `"${project.status}"`,
      `"${project.websiteUrl || ''}"`,
      `"${project.twitterUrl || ''}"`,
      `"${project.telegramUrl || ''}"`,
      `"${project.createdAt}"`
    ].join(','))
  ].join('\n');

  downloadFile(csvContent, `${filename}.csv`, 'text/csv');
};

const exportSectorsAsCSV = (sectors: Sector[], filename: string) => {
  const headers = [
    'Name',
    'Heat Score',
    'Project Count',
    '24h Change',
    'Description',
    'Top Projects'
  ];

  const csvContent = [
    headers.join(','),
    ...sectors.map(sector => [
      `"${sector.name}"`,
      sector.heatScore,
      sector.projectCount,
      sector.change24h,
      `"${sector.description}"`,
      `"${sector.topProjects.join(', ')}"`
    ].join(','))
  ].join('\n');

  downloadFile(csvContent, `${filename}.csv`, 'text/csv');
};

const exportAsJSON = (data: any[], filename: string) => {
  const jsonContent = JSON.stringify({
    exportDate: new Date().toISOString(),
    source: 'HotWeb3.io',
    count: data.length,
    data: data
  }, null, 2);

  downloadFile(jsonContent, `${filename}.json`, 'application/json');
};

const exportAsTXT = (projects: Project[], filename: string) => {
  const txtContent = [
    '='.repeat(60),
    'HotWeb3.io - Project Export',
    '='.repeat(60),
    `Export Date: ${new Date().toLocaleDateString()}`,
    `Total Projects: ${projects.length}`,
    '='.repeat(60),
    '',
    ...projects.map((project, index) => [
      `${index + 1}. ${project.name}`,
      `   Categories: ${project.categories.join(', ')}`,
      `   Chains: ${project.chains.join(', ')}`,
      `   Heat Score: ${project.heatScore}`,
      `   Status: ${project.status}`,
      `   Description: ${project.intro}`,
      project.marketCap ? `   Market Cap: ${project.marketCap}` : '',
      project.volume24h ? `   24h Volume: ${project.volume24h}` : '',
      project.priceChange24h !== undefined ? `   24h Change: ${project.priceChange24h}%` : '',
      `   Website: ${project.websiteUrl || 'N/A'}`,
      `   Created: ${project.createdAt}`,
      '-'.repeat(40),
      ''
    ].filter(line => line !== '').join('\n'))
  ].join('\n');

  downloadFile(txtContent, `${filename}.txt`, 'text/plain');
};

const exportSectorsAsTXT = (sectors: Sector[], filename: string) => {
  const txtContent = [
    '='.repeat(60),
    'HotWeb3.io - Sector Export',
    '='.repeat(60),
    `Export Date: ${new Date().toLocaleDateString()}`,
    `Total Sectors: ${sectors.length}`,
    '='.repeat(60),
    '',
    ...sectors.map((sector, index) => [
      `${index + 1}. ${sector.name}`,
      `   Heat Score: ${sector.heatScore}`,
      `   Project Count: ${sector.projectCount}`,
      `   24h Change: ${sector.change24h}%`,
      `   Description: ${sector.description}`,
      `   Top Projects: ${sector.topProjects.join(', ')}`,
      '-'.repeat(40),
      ''
    ].join('\n'))
  ].join('\n');

  downloadFile(txtContent, `${filename}.txt`, 'text/plain');
};

const downloadFile = (content: string, filename: string, mimeType: string) => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
};

// Quick export functions for common use cases
export const quickExportProjects = (format: 'csv' | 'json' | 'txt' = 'csv') => {
  exportProjects(mockProjects, { format });
};

export const quickExportSectors = (format: 'csv' | 'json' | 'txt' = 'csv') => {
  exportSectors(mockSectors, { format });
};

export const exportTrendingProjects = (format: 'csv' | 'json' | 'txt' = 'csv') => {
  const trendingProjects = mockProjects
    .filter(p => p.status === 'trending' || p.heatScore > 15000)
    .sort((a, b) => b.heatScore - a.heatScore);
  
  exportProjects(trendingProjects, { format });
};
