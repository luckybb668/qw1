// 安全工具集 - HotWeb3.io 安全防护模块

// 防止XSS攻击的输入清理
export function sanitizeInput(input: string): string {
  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

// API请求速率限制器
class RateLimiter {
  private requests: Map<string, number[]> = new Map();
  private maxRequests: number;
  private windowMs: number;

  constructor(maxRequests: number = 100, windowMs: number = 60000) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
  }

  isAllowed(identifier: string): boolean {
    const now = Date.now();
    const userRequests = this.requests.get(identifier) || [];
    
    // 清理过期的请求记录
    const validRequests = userRequests.filter(time => now - time < this.windowMs);
    
    if (validRequests.length >= this.maxRequests) {
      return false;
    }
    
    validRequests.push(now);
    this.requests.set(identifier, validRequests);
    return true;
  }

  getRemainingRequests(identifier: string): number {
    const now = Date.now();
    const userRequests = this.requests.get(identifier) || [];
    const validRequests = userRequests.filter(time => now - time < this.windowMs);
    return Math.max(0, this.maxRequests - validRequests.length);
  }
}

// 全局速率限制器实例
export const rateLimiter = new RateLimiter(100, 60000); // 每分钟100次请求

// API Key 验证
export function validateApiKey(apiKey: string): boolean {
  // 检查API Key格式
  const apiKeyPattern = /^hw3_[a-zA-Z0-9]{32}$/;
  return apiKeyPattern.test(apiKey);
}

// JWT Token 处理
export class TokenManager {
  private static readonly TOKEN_KEY = 'hw3_access_token';
  private static readonly REFRESH_KEY = 'hw3_refresh_token';

  static setTokens(accessToken: string, refreshToken: string): void {
    try {
      localStorage.setItem(this.TOKEN_KEY, accessToken);
      localStorage.setItem(this.REFRESH_KEY, refreshToken);
    } catch (error) {
      console.warn('Failed to store tokens:', error);
    }
  }

  static getAccessToken(): string | null {
    try {
      return localStorage.getItem(this.TOKEN_KEY);
    } catch (error) {
      console.warn('Failed to retrieve access token:', error);
      return null;
    }
  }

  static getRefreshToken(): string | null {
    try {
      return localStorage.getItem(this.REFRESH_KEY);
    } catch (error) {
      console.warn('Failed to retrieve refresh token:', error);
      return null;
    }
  }

  static clearTokens(): void {
    try {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.REFRESH_KEY);
    } catch (error) {
      console.warn('Failed to clear tokens:', error);
    }
  }

  static isTokenExpired(token: string): boolean {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return Date.now() >= payload.exp * 1000;
    } catch (error) {
      return true;
    }
  }
}

// 请求签名生成（防篡改）
export function generateRequestSignature(
  method: string, 
  url: string, 
  body: string, 
  timestamp: number,
  secretKey: string
): string {
  const message = `${method}${url}${body}${timestamp}`;
  
  // 简单的HMAC-SHA256实现（在生产环境中应使用专业库）
  const crypto = window.crypto || (window as any).msCrypto;
  if (!crypto?.subtle) {
    console.warn('Crypto API not available, using fallback');
    return btoa(message + secretKey);
  }
  
  // 这里应该使用真正的HMAC-SHA256，简化版本
  return btoa(message + secretKey);
}

// CSP (Content Security Policy) 检查
export function checkCSP(): boolean {
  try {
    // 检查是否有CSP头
    const metaCSP = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
    return !!metaCSP;
  } catch (error) {
    return false;
  }
}

// 防止SQL注入的输入验证
export function validateSQLInput(input: string): boolean {
  const sqlInjectionPattern = /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b)|['"]/i;
  return !sqlInjectionPattern.test(input);
}

// IP地址验证
export function isValidIP(ip: string): boolean {
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const ipv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  return ipv4Pattern.test(ip) || ipv6Pattern.test(ip);
}

// 加密敏感数据
export class DataEncryption {
  private static readonly key = 'hw3_encryption_key_2024';

  static encrypt(data: string): string {
    try {
      // 简单的Base64编码（生产环境应使用AES等强加密）
      return btoa(encodeURIComponent(data));
    } catch (error) {
      console.error('Encryption failed:', error);
      return data;
    }
  }

  static decrypt(encryptedData: string): string {
    try {
      return decodeURIComponent(atob(encryptedData));
    } catch (error) {
      console.error('Decryption failed:', error);
      return encryptedData;
    }
  }
}

// 安全日志记录
export class SecurityLogger {
  private static logs: Array<{
    timestamp: number;
    level: 'info' | 'warn' | 'error';
    message: string;
    details?: any;
  }> = [];

  static log(level: 'info' | 'warn' | 'error', message: string, details?: any): void {
    const logEntry = {
      timestamp: Date.now(),
      level,
      message,
      details
    };

    this.logs.push(logEntry);
    
    // 保持最近100条日志
    if (this.logs.length > 100) {
      this.logs = this.logs.slice(-100);
    }

    // 发送到服务器（如果需要）
    if (level === 'error') {
      this.sendToServer(logEntry);
    }
  }

  private static async sendToServer(logEntry: any): Promise<void> {
    try {
      await fetch('/api/security-logs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(logEntry)
      });
    } catch (error) {
      console.warn('Failed to send security log to server:', error);
    }
  }

  static getLogs(): typeof SecurityLogger.logs {
    return [...this.logs];
  }

  static clearLogs(): void {
    this.logs = [];
  }
}

// 用户行为监控
export class UserBehaviorMonitor {
  private static suspiciousActivity: number = 0;
  private static readonly MAX_SUSPICIOUS_ACTIVITY = 10;

  static trackSuspiciousActivity(activity: string): void {
    this.suspiciousActivity++;
    
    SecurityLogger.log('warn', `Suspicious activity detected: ${activity}`, {
      count: this.suspiciousActivity,
      userAgent: navigator.userAgent,
      timestamp: Date.now()
    });

    if (this.suspiciousActivity >= this.MAX_SUSPICIOUS_ACTIVITY) {
      this.blockUser();
    }
  }

  private static blockUser(): void {
    SecurityLogger.log('error', 'User blocked due to suspicious activity', {
      activityCount: this.suspiciousActivity
    });

    // 显示警告消息
    alert('检测到异常活动，您的访问已被暂时限制。如有问题请联系客服。');
    
    // 可以重定向到安全页面或禁用某些功能
    window.location.href = '/security-warning';
  }

  static resetSuspiciousActivity(): void {
    this.suspiciousActivity = 0;
  }
}

// HTTPS检查
export function ensureHTTPS(): void {
  if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
    SecurityLogger.log('warn', 'Redirecting to HTTPS');
    location.replace(`https:${location.href.substring(location.protocol.length)}`);
  }
}

// 防点击劫持
export function preventClickjacking(): void {
  if (window.top !== window.self) {
    SecurityLogger.log('error', 'Clickjacking attempt detected');
    window.top.location = window.self.location;
  }
}

// 初始化安全措施
export function initializeSecurity(): void {
  // 确保HTTPS
  ensureHTTPS();
  
  // 防点击劫持
  preventClickjacking();
  
  // 检查CSP
  if (!checkCSP()) {
    SecurityLogger.log('warn', 'No CSP detected');
  }

  // 监听右键菜单（可选的安全措施）
  document.addEventListener('contextmenu', (e) => {
    if (process.env.NODE_ENV === 'production') {
      e.preventDefault();
      UserBehaviorMonitor.trackSuspiciousActivity('right_click_disabled');
    }
  });

  // 监听开发者工具（检测F12）
  document.addEventListener('keydown', (e) => {
    if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I')) {
      if (process.env.NODE_ENV === 'production') {
        e.preventDefault();
        UserBehaviorMonitor.trackSuspiciousActivity('devtools_attempt');
      }
    }
  });

  SecurityLogger.log('info', 'Security measures initialized');
}
