import { useState, useEffect } from "react";

// 通用API请求Hook
export function useApiData<T>(endpoint: string, dependencies: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(`/api${endpoint}`);
        const result = await response.json();
        
        if (result.success) {
          setData(result.data);
        } else {
          setError(result.error || 'Unknown error');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Network error');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, dependencies);

  return { data, loading, error, refetch: () => window.location.reload() };
}

// 获取热门项目
export function useTrendingProjects(params?: {
  time_period?: string;
  limit?: number;
  sector?: string;
}) {
  const queryString = params ? new URLSearchParams(params as any).toString() : '';
  const endpoint = `/trending${queryString ? `?${queryString}` : ''}`;
  
  return useApiData<{
    projects: any[];
    total_count: number;
    time_period: string;
    last_updated: string;
  }>(endpoint, [params]);
}

// 获取板块热度图
export function useSectorHeatmap(time_period?: string) {
  const endpoint = `/sectors${time_period ? `?time_period=${time_period}` : ''}`;
  
  return useApiData<{
    sectors: any[];
    time_period: string;
    last_updated: string;
  }>(endpoint, [time_period]);
}

// 获取实时统计
export function useLiveStatistics() {
  return useApiData<{
    total_projects: number;
    active_sectors: number;
    today_trending: number;
    total_users: number;
    avg_heat_score: number;
    most_active_sector: string;
    total_heat_score: number;
    last_updated: string;
  }>('/statistics');
}

// 搜索项目
export function useSearchProjects(params: {
  q?: string;
  sectors?: string;
  chains?: string;
  limit?: number;
  offset?: number;
}) {
  const queryString = new URLSearchParams(params as any).toString();
  const endpoint = `/search?${queryString}`;
  
  return useApiData<{
    projects: any[];
    total_count: number;
    facets: {
      sectors: { name: string; count: number }[];
      chains: { name: string; count: number }[];
    };
    pagination: {
      limit: number;
      offset: number;
      has_more: boolean;
    };
  }>(endpoint, [params]);
}

// 获取项目详情
export function useProjectDetail(id: string) {
  return useApiData<{
    project: any;
    comments: any[];
    average_rating: number;
    total_comments: number;
    gpt_analysis: {
      summary: string;
      strengths: string[];
      risks: string[];
      market_potential: 'low' | 'medium' | 'high';
      confidence_score: number;
    };
  }>(`/project/${id}`, [id]);
}

// 实时数据轮询Hook
export function useRealTimeData<T>(
  endpoint: string, 
  intervalMs: number = 30000, // 30秒更新一次
  dependencies: any[] = []
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    const fetchData = async () => {
      try {
        setError(null);
        
        const response = await fetch(`/api${endpoint}`);
        const result = await response.json();
        
        if (result.success) {
          setData(result.data);
          setLastUpdated(new Date());
        } else {
          setError(result.error || 'Unknown error');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Network error');
      } finally {
        setLoading(false);
      }
    };

    // 立即执行一次
    fetchData();

    // 设置定时器
    intervalId = setInterval(fetchData, intervalMs);

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [...dependencies, intervalMs]);

  return { 
    data, 
    loading, 
    error, 
    lastUpdated,
    refetch: () => {
      setLoading(true);
      // 触发重新获取
    }
  };
}

// 缓存Hook - 本地存储数据以减少API调用
export function useCachedApiData<T>(
  endpoint: string, 
  cacheTimeMs: number = 5 * 60 * 1000, // 5分钟缓存
  dependencies: any[] = []
) {
  const cacheKey = `api_cache_${endpoint}`;
  const [data, setData] = useState<T | null>(() => {
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const { data: cachedData, timestamp } = JSON.parse(cached);
        if (Date.now() - timestamp < cacheTimeMs) {
          return cachedData;
        }
      }
    } catch (e) {
      console.warn('Failed to load cached data:', e);
    }
    return null;
  });
  
  const [loading, setLoading] = useState(!data);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (data) return; // 如果有缓存数据，不需要立即请求

    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await fetch(`/api${endpoint}`);
        const result = await response.json();
        
        if (result.success) {
          setData(result.data);
          
          // 缓存数据
          try {
            localStorage.setItem(cacheKey, JSON.stringify({
              data: result.data,
              timestamp: Date.now()
            }));
          } catch (e) {
            console.warn('Failed to cache data:', e);
          }
        } else {
          setError(result.error || 'Unknown error');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Network error');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, dependencies);

  const clearCache = () => {
    try {
      localStorage.removeItem(cacheKey);
    } catch (e) {
      console.warn('Failed to clear cache:', e);
    }
  };

  return { data, loading, error, clearCache };
}
