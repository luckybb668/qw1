import { useState, useEffect, useCallback } from 'react';
import { supabase, supabaseHelpers, type ProjectRow, type SectorRow } from '@/lib/supabase';
import { transformSupabaseProject, transformSupabaseSector } from '@/types/database';
import { mockProjects, mockSectors, type Project, type Sector } from '@/data/mockData';

interface UseSupabaseData {
  projects: Project[];
  sectors: Sector[];
  loading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

export function useSupabaseData(): UseSupabaseData {
  const [projects, setProjects] = useState<Project[]>(mockProjects); // Start with mock data
  const [sectors, setSectors] = useState<Sector[]>(mockSectors); // Start with mock data
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Try to load from Supabase first
      const [supabaseProjects, supabaseSectors] = await Promise.all([
        supabaseHelpers.getProjects(),
        supabaseHelpers.getSectors()
      ]);

      // If Supabase has data, use it; otherwise keep mock data
      if (supabaseProjects.length > 0) {
        const transformedProjects = supabaseProjects.map(transformSupabaseProject);
        setProjects(transformedProjects);
      }

      if (supabaseSectors.length > 0) {
        const transformedSectors = supabaseSectors.map(transformSupabaseSector);
        setSectors(transformedSectors);
      }

    } catch (err) {
      console.warn('Supabase not available, using mock data:', err);
      // Keep using mock data if Supabase fails
      setError('Using offline data - Supabase connection unavailable');
    } finally {
      setLoading(false);
    }
  }, []);

  const refreshData = useCallback(async () => {
    await loadData();
  }, [loadData]);

  useEffect(() => {
    loadData();

    // Set up real-time subscriptions
    const projectsSubscription = supabaseHelpers.subscribeToProjects((payload) => {
      console.log('Real-time project update:', payload);
      // Refresh data when there are changes
      loadData();
    });

    const sectorsSubscription = supabaseHelpers.subscribeToSectors((payload) => {
      console.log('Real-time sector update:', payload);
      // Refresh data when there are changes  
      loadData();
    });

    return () => {
      projectsSubscription.unsubscribe();
      sectorsSubscription.unsubscribe();
    };
  }, [loadData]);

  return {
    projects,
    sectors,
    loading,
    error,
    refreshData
  };
}

// Hook for individual project data
export function useSupabaseProject(id: string) {
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadProject() {
      setLoading(true);
      setError(null);

      try {
        const supabaseProject = await supabaseHelpers.getProject(id);
        
        if (supabaseProject) {
          setProject(transformSupabaseProject(supabaseProject));
        } else {
          // Fallback to mock data
          const mockProject = mockProjects.find(p => p.id === id);
          setProject(mockProject || null);
        }
      } catch (err) {
        console.warn('Supabase project fetch failed, using mock data:', err);
        // Fallback to mock data
        const mockProject = mockProjects.find(p => p.id === id);
        setProject(mockProject || null);
        setError('Using offline data');
      } finally {
        setLoading(false);
      }
    }

    if (id) {
      loadProject();
    }
  }, [id]);

  return { project, loading, error };
}

// Hook for initializing database with mock data (for development)
export function useInitializeDatabase() {
  const [initializing, setInitializing] = useState(false);

  const initializeWithMockData = useCallback(async () => {
    setInitializing(true);
    
    try {
      // Transform and insert mock projects
      const supabaseProjects = mockProjects.map(project => ({
        id: project.id,
        name: project.name,
        logo: project.logo,
        intro: project.intro,
        description: project.description,
        categories: project.categories,
        chains: project.chains,
        twitter_url: project.twitterUrl,
        telegram_url: project.telegramUrl,
        discord_url: project.discordUrl,
        website_url: project.websiteUrl,
        heat_score: project.heatScore,
        source_platform: project.sourcePlatform,
        created_at: project.createdAt,
        market_cap: project.marketCap,
        volume_24h: project.volume24h,
        price_change_24h: project.priceChange24h,
        followers: project.followers as any,
        tags: project.tags,
        status: project.status,
        updated_at: new Date().toISOString(),
      }));

      // Transform and insert mock sectors
      const supabaseSectors = mockSectors.map(sector => ({
        id: sector.id,
        name: sector.name,
        heat_score: sector.heatScore,
        project_count: sector.projectCount,
        color: sector.color,
        change_24h: sector.change24h,
        description: sector.description,
        top_projects: sector.topProjects,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }));

      await Promise.all([
        supabase.from('projects').upsert(supabaseProjects, { onConflict: 'id' }),
        supabase.from('sectors').upsert(supabaseSectors, { onConflict: 'id' })
      ]);

      console.log('Database initialized with mock data');
    } catch (error) {
      console.error('Failed to initialize database:', error);
    } finally {
      setInitializing(false);
    }
  }, []);

  return { initializeWithMockData, initializing };
}
