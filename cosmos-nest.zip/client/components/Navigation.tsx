import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { TrendingUp, Menu, X, Search, Star } from "lucide-react";
import { useState } from "react";

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="border-b border-gray-800 bg-gray-900/95 backdrop-blur supports-[backdrop-filter]:bg-gray-900/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
                HotWeb3.io
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6">
              <Link
                to="/"
                className="text-white hover:text-green-400 px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1"
              >
                <TrendingUp className="h-4 w-4" />
                <span>Trending</span>
              </Link>
              <Link
                to="/sectors"
                className="text-gray-300 hover:text-green-400 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Sectors
              </Link>
              <Link
                to="/directory"
                className="text-gray-300 hover:text-green-400 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Projects
              </Link>
              <Link
                to="/new"
                className="text-gray-300 hover:text-green-400 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                New
              </Link>
            </div>
          </div>

          {/* Desktop Right Side */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-300 hover:text-green-400 hover:bg-gray-800">
              <Search className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-green-500 hover:text-white hover:border-green-500">
              <Star className="h-4 w-4 mr-1" />
              Subscribe
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="hover:text-crypto-green"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-border">
              <Link
                to="/"
                className="text-foreground hover:text-crypto-green block px-3 py-2 rounded-md text-base font-medium transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Trending Projects
              </Link>
              <Link
                to="/sectors"
                className="text-muted-foreground hover:text-crypto-green block px-3 py-2 rounded-md text-base font-medium transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sector Heatmap
              </Link>
              <Link
                to="/directory"
                className="text-muted-foreground hover:text-crypto-green block px-3 py-2 rounded-md text-base font-medium transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Project Directory
              </Link>
              <Link
                to="/new"
                className="text-muted-foreground hover:text-crypto-green block px-3 py-2 rounded-md text-base font-medium transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                New Projects
              </Link>
              <div className="pt-4 pb-3 border-t border-border">
                <Button variant="outline" className="w-full justify-center hover:bg-crypto-green hover:text-white">
                  <Star className="h-4 w-4 mr-1" />
                  Subscribe Updates
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
