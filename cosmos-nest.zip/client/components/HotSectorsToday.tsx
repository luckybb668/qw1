import { TrendingUp, TrendingDown, Flame, ArrowRight, Activity } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { mockSectors, formatHeatScore } from "@/data/mockData";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

export function HotSectorsToday() {
  // Get top 5 hottest sectors
  const hotSectors = [...mockSectors]
    .sort((a, b) => b.heatScore - a.heatScore)
    .slice(0, 5);

  const getHeatIntensity = (score: number) => {
    const maxScore = Math.max(...mockSectors.map((s) => s.heatScore));
    const intensity = score / maxScore;
    return intensity;
  };

  const getSectorIcon = (sectorName: string) => {
    const icons: Record<string, string> = {
      'AI': '🤖',
      'DeFi': '💰', 
      'NFT': '🎨',
      'GameFi': '🎮',
      'SocialFi': '👥',
      'Memecoin': '🐕',
      'Layer2': '⚡',
      'ZK': '🔒',
      'DePIN': '🌐',
      'Infrastructure': '🏗️'
    };
    return icons[sectorName] || '🔥';
  };

  return (
    <section className="py-16 bg-gradient-to-r from-background via-muted/10 to-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-crypto-green animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-16 h-16 rounded-full bg-crypto-blue animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-12 h-12 rounded-full bg-crypto-purple animate-pulse delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-crypto-orange to-crypto-red flex items-center justify-center animate-pulse">
              <Flame className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-crypto-orange to-crypto-red bg-clip-text text-transparent">
              🔥 Hot Sectors Today
            </h2>
          </div>
          <p className="text-lg text-muted-foreground">
            当下最火的Web3行业分类 · Real-time sector heat rankings
          </p>
        </div>

        {/* Hot Sectors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          {hotSectors.map((sector, index) => {
            const intensity = getHeatIntensity(sector.heatScore);
            const isTop = index === 0;
            
            return (
              <Card
                key={sector.id}
                className={cn(
                  "group cursor-pointer transition-all duration-300 hover:scale-105 border-border relative overflow-hidden",
                  isTop && "ring-2 ring-crypto-orange/50 scale-105",
                  "hover:shadow-2xl hover:border-crypto-orange/50"
                )}
                style={{
                  background: isTop 
                    ? `linear-gradient(135deg, hsla(var(--crypto-orange), 0.15) 0%, hsla(var(--crypto-red), 0.1) 100%)`
                    : `linear-gradient(135deg, hsla(var(--${sector.color}), ${intensity * 0.8}) 0%, hsla(var(--${sector.color}), ${intensity * 0.4}) 100%)`,
                }}
              >
                <CardContent className="p-4 relative z-10">
                  {/* Rank badge */}
                  <div className="flex items-center justify-between mb-3">
                    <Badge 
                      variant={isTop ? "default" : "secondary"}
                      className={cn(
                        "text-xs font-bold",
                        isTop && "bg-gradient-to-r from-crypto-orange to-crypto-red text-white animate-pulse"
                      )}
                    >
                      #{index + 1}
                    </Badge>
                    <div className={cn(
                      "text-xs px-2 py-1 rounded-full flex items-center space-x-1",
                      sector.change24h >= 0 
                        ? "bg-crypto-green/20 text-crypto-green" 
                        : "bg-crypto-red/20 text-crypto-red"
                    )}>
                      {sector.change24h >= 0 ? 
                        <TrendingUp className="h-3 w-3" /> : 
                        <TrendingDown className="h-3 w-3" />
                      }
                      <span>{Math.abs(sector.change24h)}%</span>
                    </div>
                  </div>

                  {/* Sector info */}
                  <div className="text-center">
                    <div className="text-2xl mb-2">{getSectorIcon(sector.name)}</div>
                    <h3 className={cn(
                      "font-bold text-lg mb-2 group-hover:text-crypto-orange transition-colors",
                      isTop && "text-crypto-orange"
                    )}>
                      {sector.name}
                    </h3>
                    
                    <div className="flex items-center justify-center space-x-1 mb-2">
                      <Activity className="h-3 w-3 text-crypto-green" />
                      <span className="text-xl font-bold text-foreground">
                        {formatHeatScore(sector.heatScore)}
                      </span>
                    </div>
                    
                    <div className="text-xs text-muted-foreground mb-3">
                      {sector.projectCount} projects
                    </div>

                    {/* Heat bar */}
                    <div className="w-full bg-border/30 rounded-full h-2 overflow-hidden mb-3">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all duration-1000",
                          isTop ? "bg-gradient-to-r from-crypto-orange to-crypto-red" : `bg-${sector.color}`
                        )}
                        style={{ width: `${intensity * 100}%` }}
                      />
                    </div>

                    {isTop && (
                      <div className="flex items-center justify-center text-xs text-crypto-orange font-semibold animate-pulse">
                        <Flame className="h-3 w-3 mr-1" />
                        HOTTEST TODAY
                      </div>
                    )}
                  </div>
                </CardContent>
                
                {/* Glow effect for top sector */}
                {isTop && (
                  <div className="absolute inset-0 bg-gradient-to-t from-crypto-orange/10 to-transparent opacity-60 animate-pulse" />
                )}
              </Card>
            );
          })}
        </div>

        {/* Quick insights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Hottest sector */}
          <Card className="border-crypto-orange/30 bg-gradient-to-br from-crypto-orange/5 to-transparent">
            <CardContent className="p-6 text-center">
              <div className="text-4xl mb-2">{getSectorIcon(hotSectors[0].name)}</div>
              <h4 className="font-bold text-crypto-orange mb-1">Today's Winner</h4>
              <p className="text-2xl font-bold text-foreground">{hotSectors[0].name}</p>
              <p className="text-sm text-muted-foreground">
                Leading with {formatHeatScore(hotSectors[0].heatScore)} heat score
              </p>
            </CardContent>
          </Card>

          {/* Biggest mover */}
          <Card className="border-crypto-green/30 bg-gradient-to-br from-crypto-green/5 to-transparent">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-crypto-green mx-auto mb-2" />
              <h4 className="font-bold text-crypto-green mb-1">Biggest Mover</h4>
              <p className="text-2xl font-bold text-foreground">
                +{Math.max(...hotSectors.map(s => s.change24h)).toFixed(1)}%
              </p>
              <p className="text-sm text-muted-foreground">24h growth leader</p>
            </CardContent>
          </Card>

          {/* Total activity */}
          <Card className="border-crypto-blue/30 bg-gradient-to-br from-crypto-blue/5 to-transparent">
            <CardContent className="p-6 text-center">
              <Activity className="h-8 w-8 text-crypto-blue mx-auto mb-2" />
              <h4 className="font-bold text-crypto-blue mb-1">Total Activity</h4>
              <p className="text-2xl font-bold text-foreground">
                {formatHeatScore(hotSectors.reduce((sum, s) => sum + s.heatScore, 0))}
              </p>
              <p className="text-sm text-muted-foreground">Combined heat score</p>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/sectors">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-crypto-orange to-crypto-red hover:from-crypto-orange/90 hover:to-crypto-red/90 text-white shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Flame className="mr-2 h-5 w-5" />
              View Complete Heatmap
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
