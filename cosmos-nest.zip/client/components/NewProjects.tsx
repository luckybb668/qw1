import { Sparkles, ExternalLink, Calendar } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { mockProjects } from "@/data/mockData";

export function NewProjects() {
  const newProjects = mockProjects
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 6);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  return (
    <section className="py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-3 mb-8">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-crypto-orange to-crypto-red flex items-center justify-center">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-foreground">Newly Added Projects</h2>
          <span className="text-sm text-muted-foreground">Latest additions to our directory</span>
        </div>

        <div className="space-y-4">
          {newProjects.map((project) => (
            <Card key={project.id} className="hover:shadow-md transition-all duration-300 border-border bg-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <img
                      src={project.logo}
                      alt={project.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-border"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h3 className="font-semibold text-foreground hover:text-crypto-green transition-colors">
                          {project.name}
                        </h3>
                        <div className="flex items-center space-x-1 text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span className="text-sm">{formatDate(project.createdAt)}</span>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mt-1 max-w-md">
                        {project.intro}
                      </p>
                      
                      <div className="flex items-center space-x-2 mt-2">
                        <div className="flex flex-wrap gap-1">
                          {project.categories.map((category) => (
                            <span
                              key={category}
                              className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded-md"
                            >
                              {category}
                            </span>
                          ))}
                        </div>
                        <span className="text-muted-foreground">•</span>
                        <div className="flex flex-wrap gap-1">
                          {project.chains.map((chain) => (
                            <span
                              key={chain}
                              className="px-2 py-1 bg-accent text-accent-foreground text-xs rounded-md"
                            >
                              {chain}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {project.websiteUrl && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="hover:bg-crypto-green/10 hover:text-crypto-green"
                        asChild
                      >
                        <a href={project.websiteUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                    
                    {project.twitterUrl && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="hover:bg-crypto-blue/10 hover:text-crypto-blue"
                        asChild
                      >
                        <a href={project.twitterUrl} target="_blank" rel="noopener noreferrer">
                          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                          </svg>
                        </a>
                      </Button>
                    )}
                    
                    {project.telegramUrl && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="hover:bg-crypto-blue/10 hover:text-crypto-blue"
                        asChild
                      >
                        <a href={project.telegramUrl} target="_blank" rel="noopener noreferrer">
                          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.568 8.16l-1.61 7.548c-.121.546-.44.68-.892.424l-2.463-1.818-1.19 1.146c-.131.131-.243.243-.499.243l.178-2.516L15.672 9.6c.131-.117-.029-.183-.203-.066l-3.47 2.185-2.107-.658c-.457-.142-.466-.457.096-.676l8.252-3.181c.381-.142.714.088.59.676z" />
                          </svg>
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-8">
          <Button variant="outline" className="hover:bg-crypto-green hover:text-white">
            View All New Projects
          </Button>
        </div>
      </div>
    </section>
  );
}
