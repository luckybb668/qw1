import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  TrendingUp, Menu, X, Search, Star, Shield, Zap, Bell,
  Activity, BarChart3, Globe
} from "lucide-react";
import { ThemeToggle, useTheme } from "@/contexts/ThemeContext";

export function EnhancedNavigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { effectiveTheme } = useTheme();

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${
      effectiveTheme === 'dark' 
        ? 'bg-gray-900/80 border-gray-800/50' 
        : 'bg-white/80 border-gray-200/50'
    } backdrop-blur-xl border-b`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="relative">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <TrendingUp className="h-5 w-5 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-orange-400 to-red-400 rounded-full animate-pulse"></div>
              </div>
              <div>
                <span className="text-xl font-bold bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                  HotWeb3.io
                </span>
                <div className="text-xs text-muted-foreground">AI-Powered Analytics</div>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="flex items-center space-x-1 bg-background/50 backdrop-blur-sm rounded-xl p-1">
              <Link
                to="/"
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 text-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
              >
                <TrendingUp className="h-4 w-4" />
                <span>热门</span>
              </Link>
              <Link
                to="/sectors"
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 text-muted-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
              >
                <Activity className="h-4 w-4" />
                <span>板块</span>
              </Link>
              <Link
                to="/directory"
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 text-muted-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
              >
                <BarChart3 className="h-4 w-4" />
                <span>项目</span>
              </Link>
              <Link
                to="/new"
                className="flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 text-muted-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
              >
                <Zap className="h-4 w-4" />
                <span>新项目</span>
              </Link>
            </div>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* 搜索按钮 */}
            <Button 
              variant="ghost" 
              size="sm" 
              className="hidden md:flex hover:bg-cyan-500/10 hover:text-cyan-500"
            >
              <Search className="h-4 w-4" />
            </Button>

            {/* 通知按钮 */}
            <Button 
              variant="ghost" 
              size="sm" 
              className="hidden md:flex relative hover:bg-cyan-500/10 hover:text-cyan-500"
            >
              <Bell className="h-4 w-4" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            </Button>

            {/* 主题切换 */}
            <div className="hidden md:block">
              <ThemeToggle />
            </div>


            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="hover:bg-cyan-500/10 hover:text-cyan-500"
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border/50">
            <div className="px-2 pt-4 pb-6 space-y-2">
              <Link
                to="/"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 text-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                <TrendingUp className="h-5 w-5" />
                <span>热门项目</span>
              </Link>
              <Link
                to="/sectors"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 text-muted-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                <Activity className="h-5 w-5" />
                <span>板块热度图</span>
              </Link>
              <Link
                to="/directory"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 text-muted-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                <BarChart3 className="h-5 w-5" />
                <span>项目导航</span>
              </Link>
              <Link
                to="/new"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 text-muted-foreground hover:bg-cyan-500/10 hover:text-cyan-500"
                onClick={() => setMobileMenuOpen(false)}
              >
                <Zap className="h-5 w-5" />
                <span>新项目速览</span>
              </Link>
              
              {/* Mobile actions */}
              <div className="pt-4 border-t border-border/50">
                <div className="px-4">
                  <ThemeToggle />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 安全提示条 */}
      <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-b border-cyan-500/20">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-center space-x-2 text-sm">
            <Shield className="h-4 w-4 text-cyan-400" />
            <span className="text-muted-foreground">
              🔒 数据已加密保护 · 
              <span className="text-cyan-400 font-medium"> SSL安全连接</span> · 
              实时更新中 · 
              <span className="text-green-400">99.9% 在线率</span>
            </span>
          </div>
        </div>
      </div>
    </nav>
  );
}
