import { Globe, Mail, MessageCircle, TrendingUp, Activity, BarChart3, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-br from-muted/50 to-background border-t border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main footer content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-crypto-green to-crypto-blue flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-crypto-green to-crypto-blue bg-clip-text text-transparent">
                HotWeb3.io
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              全球Web3热度导航平台，实时追踪项目热度、行业趋势，帮助投资者和项目方把握Web3脉搏。
            </p>
            <div className="flex items-center space-x-2">
              <div className="h-2 w-2 rounded-full bg-crypto-green animate-pulse"></div>
              <span className="text-xs text-crypto-green font-semibold">LIVE</span>
              <span className="text-xs text-muted-foreground">实时数据更新中</span>
            </div>
          </div>

          {/* Navigation links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">平台功能</h4>
            <div className="space-y-2">
              <Link to="/" className="flex items-center space-x-2 text-sm text-muted-foreground hover:text-crypto-green transition-colors">
                <TrendingUp className="h-4 w-4" />
                <span>热门项目</span>
              </Link>
              <Link to="/sectors" className="flex items-center space-x-2 text-sm text-muted-foreground hover:text-crypto-green transition-colors">
                <Activity className="h-4 w-4" />
                <span>行业热度图</span>
              </Link>
              <Link to="/directory" className="flex items-center space-x-2 text-sm text-muted-foreground hover:text-crypto-green transition-colors">
                <BarChart3 className="h-4 w-4" />
                <span>项目导航</span>
              </Link>
              <Link to="/new" className="flex items-center space-x-2 text-sm text-muted-foreground hover:text-crypto-green transition-colors">
                <Zap className="h-4 w-4" />
                <span>新项目速览</span>
              </Link>
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">热门分类</h4>
            <div className="flex flex-wrap gap-2">
              {['AI', 'DeFi', 'NFT', 'GameFi', 'SocialFi', 'Memecoin', 'Layer2', 'ZK'].map(category => (
                <Badge 
                  key={category} 
                  variant="secondary" 
                  className="text-xs hover:bg-crypto-green hover:text-white cursor-pointer transition-colors"
                >
                  {category}
                </Badge>
              ))}
            </div>
            <div className="text-xs text-muted-foreground">
              <span className="text-crypto-green font-semibold">当前最热:</span> Memecoin (+45.6%)
            </div>
          </div>

          {/* Newsletter signup */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">订阅更新</h4>
            <p className="text-sm text-muted-foreground">
              获取每日热度报告和新项目提醒
            </p>
            <div className="space-y-2">
              <Input 
                placeholder="输入邮箱地址" 
                className="text-sm"
              />
              <Button 
                size="sm" 
                className="w-full bg-gradient-to-r from-crypto-green to-crypto-blue hover:from-crypto-green/90 hover:to-crypto-blue/90 text-white"
              >
                <Mail className="h-4 w-4 mr-2" />
                订阅免费报告
              </Button>
            </div>
            <div className="text-xs text-muted-foreground">
              每周发送，随时可退订
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Statistics bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="text-center p-3 rounded-lg bg-crypto-green/10">
            <div className="text-lg font-bold text-crypto-green">1,024</div>
            <div className="text-xs text-muted-foreground">项目已收录</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-crypto-blue/10">
            <div className="text-lg font-bold text-crypto-blue">152K</div>
            <div className="text-xs text-muted-foreground">今日总热度</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-crypto-purple/10">
            <div className="text-lg font-bold text-crypto-purple">50+</div>
            <div className="text-xs text-muted-foreground">新增项目</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-crypto-orange/10">
            <div className="text-lg font-bold text-crypto-orange">24/7</div>
            <div className="text-xs text-muted-foreground">实时监控</div>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Bottom section */}
        <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <span>© {currentYear} HotWeb3.io</span>
            <span>·</span>
            <span>投资者、项目方、玩家都在用的行业温度计</span>
          </div>

          <div className="flex items-center space-x-4">
            {/* Social links */}
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-crypto-blue/10 hover:text-crypto-blue">
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-crypto-blue/10 hover:text-crypto-blue">
              <MessageCircle className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-crypto-green/10 hover:text-crypto-green">
              <Mail className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Bottom tagline */}
        <div className="text-center mt-8 pt-6 border-t border-border">
          <p className="text-sm text-muted-foreground">
            🔥 <span className="text-crypto-orange font-semibold">每天一分钟，掌握全球Web3热度趋势</span> 🔥
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            数据来源：Twitter, Telegram, Discord · 实时更新 · 专业分析
          </p>
        </div>
      </div>
    </footer>
  );
}
