import { useState } from "react";
import { Download, FileText, Database, File } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { exportProjects, exportSectors, quickExportProjects, quickExportSectors, type ExportOptions } from "@/utils/dataExport";
import { mockProjects, mockSectors, type Project, type Sector } from "@/data/mockData";

interface ExportDialogProps {
  data?: Project[] | Sector[];
  type: 'projects' | 'sectors';
  trigger?: React.ReactNode;
}

export function ExportDialog({ data, type, trigger }: ExportDialogProps) {
  const [format, setFormat] = useState<'csv' | 'json' | 'txt'>('csv');
  const [includeAllFields, setIncludeAllFields] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [open, setOpen] = useState(false);

  const dataToExport = data || (type === 'projects' ? mockProjects : mockSectors);
  const itemCount = dataToExport.length;

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      const options: ExportOptions = {
        format,
        includeAllFields
      };

      if (type === 'projects') {
        exportProjects(dataToExport as Project[], options);
      } else {
        exportSectors(dataToExport as Sector[], options);
      }

      // Close dialog after successful export
      setTimeout(() => {
        setOpen(false);
        setIsExporting(false);
      }, 1000);
    } catch (error) {
      console.error('Export failed:', error);
      setIsExporting(false);
    }
  };

  const formatInfo = {
    csv: {
      icon: FileText,
      name: 'CSV (Comma Separated)',
      description: 'Best for spreadsheets like Excel, Google Sheets',
      size: '~50KB'
    },
    json: {
      icon: Database,
      name: 'JSON (JavaScript Object)',
      description: 'Best for developers and data analysis tools',
      size: '~80KB'
    },
    txt: {
      icon: File,
      name: 'TXT (Plain Text)',
      description: 'Human-readable format for viewing and printing',
      size: '~60KB'
    }
  };

  const currentFormat = formatInfo[format];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5" />
            <span>Export {type === 'projects' ? 'Projects' : 'Sectors'}</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Data Summary */}
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div>
              <div className="font-semibold text-sm">
                {itemCount} {type === 'projects' ? 'Projects' : 'Sectors'}
              </div>
              <div className="text-xs text-muted-foreground">
                Ready for export
              </div>
            </div>
            <Badge variant="secondary">{itemCount} items</Badge>
          </div>

          <Separator />

          {/* Format Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Export Format</Label>
            <Select value={format} onValueChange={(value) => setFormat(value as any)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-4 w-4" />
                    <span>CSV - Excel Compatible</span>
                  </div>
                </SelectItem>
                <SelectItem value="json">
                  <div className="flex items-center space-x-2">
                    <Database className="h-4 w-4" />
                    <span>JSON - Developer Format</span>
                  </div>
                </SelectItem>
                <SelectItem value="txt">
                  <div className="flex items-center space-x-2">
                    <File className="h-4 w-4" />
                    <span>TXT - Plain Text</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>

            {/* Format Info */}
            <div className="p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-2 mb-1">
                <currentFormat.icon className="h-4 w-4 text-crypto-blue" />
                <span className="font-medium text-sm">{currentFormat.name}</span>
                <Badge variant="outline" className="text-xs">{currentFormat.size}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{currentFormat.description}</p>
            </div>
          </div>

          <Separator />

          {/* Options */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Export Options</Label>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="include-all"
                checked={includeAllFields}
                onCheckedChange={setIncludeAllFields}
              />
              <Label htmlFor="include-all" className="text-sm">
                Include all available fields
              </Label>
            </div>
            <p className="text-xs text-muted-foreground">
              {includeAllFields 
                ? "Exports all data including URLs, descriptions, and metadata"
                : "Exports only essential fields like name, category, and heat score"
              }
            </p>
          </div>

          <Separator />

          {/* Action Buttons */}
          <div className="flex space-x-2">
            <Button 
              onClick={handleExport}
              disabled={isExporting}
              className="flex-1 bg-gradient-to-r from-crypto-green to-crypto-blue hover:from-crypto-green/90 hover:to-crypto-blue/90"
            >
              {isExporting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Export Data
                </>
              )}
            </Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
          </div>

          {/* Quick Export Options */}
          <div className="pt-2 border-t border-border">
            <Label className="text-xs text-muted-foreground mb-2 block">Quick Actions:</Label>
            <div className="flex space-x-2">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  if (type === 'projects') quickExportProjects('csv');
                  else quickExportSectors('csv');
                  setOpen(false);
                }}
                className="text-xs"
              >
                All as CSV
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  if (type === 'projects') quickExportProjects('json');
                  else quickExportSectors('json');
                  setOpen(false);
                }}
                className="text-xs"
              >
                All as JSON
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
