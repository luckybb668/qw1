import { useState, useMemo } from "react";
import { Search, TrendingUp, Filter, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { mockProjects, formatHeatScore, searchProjects, type Project } from "@/data/mockData";
import { Link } from "react-router-dom";

export function SearchSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showResults, setShowResults] = useState(false);

  const searchResults = useMemo(() => {
    if (searchQuery.trim().length < 2) return [];
    return searchProjects(searchQuery).slice(0, 6);
  }, [searchQuery]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setShowResults(query.trim().length >= 2);
  };

  const clearSearch = () => {
    setSearchQuery("");
    setShowResults(false);
  };

  const popularSearches = [
    { term: "Memecoin", trend: "+45.6%", hot: true },
    { term: "AI", trend: "+15.4%", hot: false },
    { term: "Friend.Tech", trend: "+20.4%", hot: false },
    { term: "DeFi", trend: "+5.3%", hot: false },
    { term: "Jupiter", trend: "+8.2%", hot: false },
    { term: "SocialFi", trend: "+22.1%", hot: false }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-background to-muted/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            发现Web3项目 · Discover Projects
          </h2>
          <p className="text-muted-foreground mb-8">
            搜索项目、分类或区块链网络 · Search projects, sectors, or chains
          </p>

          {/* Search Input */}
          <div className="relative mb-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="搜索项目名称、分类或区块链..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-12 pr-12 py-4 text-lg border-2 focus:border-crypto-green"
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearSearch}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 hover:bg-muted"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>

            {/* Search Results Dropdown */}
            {showResults && (
              <Card className="absolute top-full mt-2 w-full z-50 border-border bg-card shadow-lg">
                <CardContent className="p-0">
                  {searchResults.length > 0 ? (
                    <>
                      {searchResults.map((project) => (
                        <Link
                          key={project.id}
                          to={`/project/${project.id}`}
                          className="block hover:bg-muted/50 transition-colors"
                          onClick={() => setShowResults(false)}
                        >
                          <div className="p-4 border-b border-border last:border-0">
                            <div className="flex items-center space-x-3">
                              <img
                                src={project.logo}
                                alt={project.name}
                                className="w-10 h-10 rounded-full object-cover border border-border"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2">
                                  <h4 className="font-semibold text-foreground text-sm">
                                    {project.name}
                                  </h4>
                                  <div className="flex items-center space-x-1">
                                    <TrendingUp className="h-3 w-3 text-crypto-green" />
                                    <span className="text-xs text-crypto-green font-semibold">
                                      {formatHeatScore(project.heatScore)}
                                    </span>
                                  </div>
                                </div>
                                <p className="text-xs text-muted-foreground truncate">
                                  {project.intro}
                                </p>
                                <div className="flex space-x-1 mt-1">
                                  {project.categories.slice(0, 2).map((category) => (
                                    <Badge key={category} variant="secondary" className="text-xs">
                                      {category}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        </Link>
                      ))}
                      <div className="p-3 border-t border-border bg-muted/20">
                        <Link
                          to={`/directory?search=${encodeURIComponent(searchQuery)}`}
                          className="text-sm text-crypto-green hover:text-crypto-green/80 transition-colors"
                          onClick={() => setShowResults(false)}
                        >
                          View all {searchResults.length}+ results →
                        </Link>
                      </div>
                    </>
                  ) : (
                    <div className="p-4 text-center text-muted-foreground">
                      <div className="text-sm">No projects found for "{searchQuery}"</div>
                      <div className="text-xs mt-1">Try searching for categories like "DeFi" or "AI"</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Popular Searches */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="text-sm text-muted-foreground mr-2">热门搜索:</span>
            {popularSearches.map((item) => (
              <Button
                key={item.term}
                variant="outline"
                size="sm"
                onClick={() => handleSearch(item.term)}
                className={`hover:bg-crypto-green hover:text-white transition-colors relative ${
                  item.hot ? 'border-crypto-orange text-crypto-orange' : ''
                }`}
              >
                {item.term}
                {item.hot && (
                  <span className="absolute -top-1 -right-1 h-2 w-2 bg-crypto-orange rounded-full animate-pulse"></span>
                )}
                <span className="ml-1 text-xs text-crypto-green">{item.trend}</span>
              </Button>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4 mt-8">
            <Link to="/directory">
              <Button className="bg-gradient-to-r from-crypto-green to-crypto-blue hover:from-crypto-green/90 hover:to-crypto-blue/90 text-white">
                <Filter className="mr-2 h-4 w-4" />
                浏览所有项目
              </Button>
            </Link>
            <Link to="/sectors">
              <Button variant="outline" className="hover:bg-crypto-purple hover:text-white">
                <TrendingUp className="mr-2 h-4 w-4" />
                查看行业热度图
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
