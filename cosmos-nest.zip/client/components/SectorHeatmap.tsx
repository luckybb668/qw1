import { Activity, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { mockSectors, formatHeatScore } from "@/data/mockData";
import { cn } from "@/lib/utils";

export function SectorHeatmap() {
  const getHeatIntensity = (score: number) => {
    const maxScore = Math.max(...mockSectors.map((s) => s.heatScore));
    const intensity = score / maxScore;
    
    if (intensity > 0.8) return "heat-high";
    if (intensity > 0.5) return "heat-medium";
    return "heat-low";
  };

  const getHeatOpacity = (score: number) => {
    const maxScore = Math.max(...mockSectors.map((s) => s.heatScore));
    const intensity = score / maxScore;
    return Math.max(0.3, intensity);
  };

  return (
    <section className="py-12 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-3 mb-8">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-crypto-purple to-crypto-blue flex items-center justify-center">
            <Activity className="h-5 w-5 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-foreground">Sector Heatmap</h2>
          <span className="text-sm text-muted-foreground">Industry activity overview</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {mockSectors.map((sector) => {
            const heatLevel = getHeatIntensity(sector.heatScore);
            const opacity = getHeatOpacity(sector.heatScore);
            
            return (
              <Card
                key={sector.id}
                className={cn(
                  "group cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg border-border relative overflow-hidden",
                  "hover:border-crypto-green/50"
                )}
                style={{
                  background: `linear-gradient(135deg, 
                    hsla(var(--${sector.color}), ${opacity}) 0%, 
                    hsla(var(--${sector.color}), ${opacity * 0.6}) 100%)`,
                }}
              >
                <CardContent className="p-6 relative z-10">
                  <div className="text-center">
                    <h3 className="font-bold text-foreground text-lg mb-2 group-hover:text-crypto-green transition-colors">
                      {sector.name}
                    </h3>
                    
                    <div className="flex items-center justify-center space-x-1 mb-2">
                      <TrendingUp className="h-4 w-4 text-crypto-green" />
                      <span className="text-xl font-bold text-foreground">
                        {formatHeatScore(sector.heatScore)}
                      </span>
                    </div>
                    
                    <div className="text-sm text-muted-foreground">
                      {sector.projectCount} projects
                    </div>
                    
                    <div className="mt-3 w-full bg-border/30 rounded-full h-2 overflow-hidden">
                      <div
                        className={cn("h-full rounded-full transition-all duration-500", `bg-${sector.color}`)}
                        style={{ width: `${opacity * 100}%` }}
                      />
                    </div>
                  </div>
                </CardContent>
                
                <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Card>
            );
          })}
        </div>

        <div className="mt-8 flex items-center justify-center space-x-6 text-sm text-muted-foreground">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-heat-low border border-border" />
            <span>Low Activity</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-heat-medium border border-border" />
            <span>Medium Activity</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-heat-high border border-border" />
            <span>High Activity</span>
          </div>
        </div>
      </div>
    </section>
  );
}
