import { useState } from "react";
import { TrendingUp, ExternalLink, Filter, BarChart3, Star, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { mockProjects, formatHeatScore, getAllCategories, formatPriceChange } from "@/data/mockData";
import { Link } from "react-router-dom";

type TimeFilter = '24h' | '7d' | '30d';
type CategoryFilter = 'all' | string;

export function TrendingProjects() {
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('24h');
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>('all');
  const [showAll, setShowAll] = useState(false);

  const categories = getAllCategories();

  const filteredProjects = mockProjects
    .filter(project => {
      if (categoryFilter === 'all') return true;
      return project.categories.includes(categoryFilter);
    })
    .sort((a, b) => b.heatScore - a.heatScore);

  const displayProjects = showAll ? filteredProjects : filteredProjects.slice(0, 8);

  return (
    <section className="py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-8">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-crypto-green to-crypto-orange flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-foreground">Trending Projects</h2>
            <Badge variant="secondary">{displayProjects.length} projects</Badge>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Tabs value={timeFilter} onValueChange={(value) => setTimeFilter(value as TimeFilter)}>
              <TabsList>
                <TabsTrigger value="24h">24h</TabsTrigger>
                <TabsTrigger value="7d">7d</TabsTrigger>
                <TabsTrigger value="30d">30d</TabsTrigger>
              </TabsList>
            </Tabs>

            <Link to="/directory">
              <Button variant="outline" size="sm">
                <BarChart3 className="h-4 w-4 mr-1" />
                View All
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayProjects.map((project, index) => (
            <Card
              key={project.id}
              className="group hover:shadow-lg transition-all duration-300 border-border bg-card hover:bg-accent/5"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img
                        src={project.logo}
                        alt={project.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-border"
                      />
                      <div className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                        {index + 1}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-sm group-hover:text-crypto-green transition-colors">
                        {project.name}
                      </h3>
                      <div className="flex items-center space-x-1 mt-1">
                        <TrendingUp className="h-3 w-3 text-crypto-green" />
                        <span className="text-lg font-bold text-crypto-green">
                          {formatHeatScore(project.heatScore)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground mb-4 line-clamp-2">
                  {project.intro}
                </p>

                <div className="flex flex-wrap gap-1 mb-3">
                  {project.categories.slice(0, 2).map((category) => (
                    <Badge key={category} variant="secondary" className="text-xs">
                      {category}
                    </Badge>
                  ))}
                </div>

                {project.priceChange24h !== undefined && (
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="text-muted-foreground">24h:</span>
                    <span className={formatPriceChange(project.priceChange24h).color}>
                      {formatPriceChange(project.priceChange24h).value}
                    </span>
                  </div>
                )}

                {project.marketCap && (
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="text-muted-foreground">Market Cap:</span>
                    <span className="font-semibold">{project.marketCap}</span>
                  </div>
                )}

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-1">
                      {project.twitterUrl && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 hover:bg-crypto-blue/10 hover:text-crypto-blue"
                          asChild
                        >
                          <a href={project.twitterUrl} target="_blank" rel="noopener noreferrer">
                            <svg className="h-3 w-3" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                            </svg>
                          </a>
                        </Button>
                      )}
                      {project.telegramUrl && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 hover:bg-crypto-blue/10 hover:text-crypto-blue"
                          asChild
                        >
                          <a href={project.telegramUrl} target="_blank" rel="noopener noreferrer">
                            <svg className="h-3 w-3" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.568 8.16l-1.61 7.548c-.121.546-.44.68-.892.424l-2.463-1.818-1.19 1.146c-.131.131-.243.243-.499.243l.178-2.516L15.672 9.6c.131-.117-.029-.183-.203-.066l-3.47 2.185-2.107-.658c-.457-.142-.466-.457.096-.676l8.252-3.181c.381-.142.714.088.59.676z" />
                            </svg>
                          </a>
                        </Button>
                      )}
                      {project.websiteUrl && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 hover:bg-crypto-green/10 hover:text-crypto-green"
                          asChild
                        >
                          <a href={project.websiteUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 w-7 p-0 hover:bg-yellow-500/10 hover:text-yellow-500"
                    >
                      <Star className="h-3 w-3" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{project.sourcePlatform}</span>
                    <Link to={`/project/${project.id}`}>
                      <Button size="sm" variant="outline" className="text-xs h-7 hover:bg-crypto-green hover:text-white">
                        Details
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Show More/Less Button */}
        {filteredProjects.length > 8 && (
          <div className="text-center mt-8">
            <Button
              variant="outline"
              onClick={() => setShowAll(!showAll)}
              className="hover:bg-crypto-green hover:text-white"
            >
              {showAll ? (
                <>Show Less</>
              ) : (
                <>
                  Show All {filteredProjects.length} Projects
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        )}

        {filteredProjects.length === 0 && (
          <div className="text-center py-12">
            <div className="text-muted-foreground text-lg mb-2">No projects found</div>
            <p className="text-sm text-muted-foreground">
              Try selecting a different category or check back later for new projects.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
